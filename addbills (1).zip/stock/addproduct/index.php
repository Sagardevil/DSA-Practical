<?php
include('../../auth.php');
check_login();
// Rest of the code...
?>
<?php
// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Function to add a new product to list_of_products table
function addNewProduct($conn, $product_name, $product_rate, $product_quantity = null)
{
    // Sanitize inputs to prevent SQL injection
    $product_name = $conn->real_escape_string($product_name);
    $product_rate = $conn->real_escape_string($product_rate);
    $product_quantity = $product_quantity !== null ? $conn->real_escape_string($product_quantity) : null;
    
    if ($product_quantity === null) {
        $sql = "INSERT INTO list_of_products (product_name, product_rate) VALUES ('$product_name', '$product_rate')";
    } else {
        $sql = "INSERT INTO list_of_products (product_name, quantity, product_rate) VALUES ('$product_name', '$product_quantity', '$product_rate')";
    }
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>
            Swal.fire({
                title: 'Success!',
                text: 'Product added successfully',
                icon: 'success',
                confirmButtonText: 'Continue'
            }).then((result) => {
                window.location.href = '../../index.php';
            });
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                title: 'Error!',
                text: 'Failed to add product: " . $conn->error . "',
                icon: 'error',
                confirmButtonText: 'Try Again'
            });
        </script>";
    }
}
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = $_POST["product_name"];
    $product_rate = $_POST["product_rate"];
    $product_quantity = isset($_POST["product_quantity"]) ? $_POST["product_quantity"] : null;
    // Add new product to list_of_products
    addNewProduct($conn, $product_name, $product_rate, $product_quantity);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }
        
        body {
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            border: none;
            padding: 25px 20px;
        }
        
        .form-container {
            max-width: 800px;
            margin: 5% auto;
        }
        
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
        }
        
        .form-control {
            border-radius: 8px;
            padding: 12px 15px;
            border: 1px solid #ced4da;
            background-color: #f8f9fa;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
        }
        
        .input-group-text {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px 0 0 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border: none;
            border-radius: 8px;
            padding: 12px 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
            transition: all 0.3s;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(67, 97, 238, 0.4);
        }
        
        .btn-back {
            background-color: #6c757d;
            color: white;
            border-radius: 8px;
            padding: 12px 25px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s;
        }
        
        .btn-back:hover {
            background-color: #5a6268;
            color: white;
        }
        
        .floating-label {
            position: relative;
            margin-bottom: 20px;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .card-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        .card-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 300;
        }
        
        @media (max-width: 768px) {
            .form-container {
                margin: 10px;
                padding: 0;
            }
            
            .card-header {
                padding: 20px 15px;
            }
            
            .card-body {
                padding: 20px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title mb-0"><i class="fas fa-plus-circle me-2"></i>Add New Product</h2>
                        <p class="card-subtitle mb-0">Enter the details of the new product below</p>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter product name" required>
                                        <label for="product_name"><i class="fas fa-tag me-2"></i>Product Name</label>
                                        <div class="invalid-feedback">
                                            Please enter a product name.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control" id="product_quantity" name="product_quantity" placeholder="Enter quantity">
                                        <label for="product_quantity"><i class="fas fa-boxes me-2"></i>Quantity</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="number" step="0.01" class="form-control" id="product_rate" name="product_rate" placeholder="Enter rate" required>
                                        <label for="product_rate"><i class="fas fa-dollar-sign me-2"></i>Rate</label>
                                        <div class="invalid-feedback">
                                            Please enter a valid rate.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-6">
                                    <a href="../../index.php" class="btn btn-back w-100">
                                        <i class="fas fa-arrow-left me-2"></i>Back
                                    </a>
                                </div>
                                <div class="col-6">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-save me-2"></i>Save Product
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation script
        (function () {
            'use strict'
            
            // Fetch all forms we want to apply validation to
            var forms = document.querySelectorAll('.needs-validation')
            
            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
</body>
</html>