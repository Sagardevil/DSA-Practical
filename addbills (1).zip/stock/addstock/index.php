<?php
include('../../auth.php');
check_login();
// Rest of the code...
?>

<?php

// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create table for stock of the selected date
function createStockTable($conn, $date)
{
    $formatted_date = date('dmY', strtotime($date));
    $table_name = "stock_of_" . $formatted_date;

    // Check if the table already exists
    $sql = "SHOW TABLES LIKE '$table_name'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 0) {
        // Create the table if it doesn't exist
        $create_table_sql = "CREATE TABLE $table_name (
                                id INT AUTO_INCREMENT PRIMARY KEY,
                                product_name VARCHAR(255) NOT NULL,
                                product_quantity INT NOT NULL,
                                product_rate DECIMAL(10, 2) NOT NULL
                            )";
        if ($conn->query($create_table_sql) === TRUE) {
            return "Table $table_name created successfully.";
        } else {
            return "Error creating table: " . $conn->error;
        }
    } else {
        return "Table $table_name already exists.";
    }
}

// Fetch product names from list_of_products table
$product_names_query = "SELECT product_name FROM list_of_products";
$product_names_result = $conn->query($product_names_query);
$product_names = array();
if ($product_names_result && $product_names_result->num_rows > 0) {
    while ($row = $product_names_result->fetch_assoc()) {
        $product_names[] = $row['product_name'];
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST["date"];
    $product_names_post = $_POST["product_name"];
    $product_quantities = $_POST["product_quantity"];
    $product_rates = $_POST["product_rate"];

    // Create table for stock of the selected date if it doesn't exist
    $table_message = createStockTable($conn, $date);

    // Insert or update stock entries into the table
    $formatted_date = date('dmY', strtotime($date));
    $table_name = "stock_of_" . $formatted_date;
    $success = true;
    $message = "";

    foreach ($product_names_post as $key => $product_name) {
        $product_name = mysqli_real_escape_string($conn, $product_name);
        $quantity = intval($product_quantities[$key]);
        $rate = floatval($product_rates[$key]);

        // Check if the product already exists in the table
        $check_product_sql = "SELECT * FROM $table_name WHERE product_name = '$product_name'";
        $check_product_result = $conn->query($check_product_sql);

        if ($check_product_result && $check_product_result->num_rows > 0) {
            // Update the product quantity and rate
            $update_product_sql = "UPDATE $table_name SET product_quantity = product_quantity + $quantity, product_rate = $rate WHERE product_name = '$product_name'";
            if (!($conn->query($update_product_sql) === TRUE)) {
                $success = false;
                $message .= "Error updating product: " . $conn->error . "<br>";
            }
        } else {
            // Insert new product data
            $insert_product_sql = "INSERT INTO $table_name (product_name, product_quantity, product_rate) VALUES ('$product_name', $quantity, $rate)";
            if (!($conn->query($insert_product_sql) === TRUE)) {
                $success = false;
                $message .= "Error adding product: " . $conn->error . "<br>";
            }
        }

        // Update the product quantity in list_of_products table
        $update_list_of_products_sql = "UPDATE list_of_products SET quantity = quantity + $quantity WHERE product_name = '$product_name'";
        if (!($conn->query($update_list_of_products_sql) === TRUE)) {
            $success = false;
            $message .= "Error updating product quantity in list_of_products table: " . $conn->error . "<br>";
        }
    }

    // Set session message for display after redirect
    if ($success) {
        $_SESSION['success_message'] = "Stock added successfully.";
        header("Location: ../../index.php");
        exit();
    } else {
        $_SESSION['error_message'] = $message;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Stock - Tirupati Sales</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/themes/smoothness/jquery-ui.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --accent-color: #1abc9c;
            --danger-color: #e74c3c;
            --success-color: #2ecc71;
            --background-color: #f8f9fa;
            --card-bg: #ffffff;
            --text-color: #2c3e50;
            --border-radius: 12px;
            --box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-bottom: 40px;
        }

        .page-container {
            max-width: 1200px;
            margin: 20px auto;
        }

        .card {
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            border: none;
            overflow: hidden;
            background-color: var(--card-bg);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-bottom: none;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-header h2 {
            margin: 0;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .card-header h2 i {
            margin-right: 12px;
        }

        .card-body {
            padding: 30px;
        }

        .form-control, .form-select {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.25);
            border-color: var(--primary-color);
        }

        .date-container {
            position: relative;
            margin-bottom: 30px;
        }

        .date-container i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary-color);
            pointer-events: none;
        }

        .table {
            border-radius: var(--border-radius);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .table th {
            background-color: rgba(52, 152, 219, 0.1);
            color: var(--text-color);
            font-weight: 600;
            border-top: none;
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(52, 152, 219, 0.4);
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success-color), #27ae60);
            border: none;
        }

        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(46, 204, 113, 0.4);
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--danger-color), #c0392b);
            border: none;
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(231, 76, 60, 0.4);
        }

        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .stock-row {
            background-color: white;
            transition: all 0.3s;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .stock-row:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .product-input-group {
            position: relative;
        }

        .product-input-group i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--primary-color);
        }

        .floating-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(52, 152, 219, 0.5);
            cursor: pointer;
            transition: all 0.3s;
            z-index: 100;
        }

        .floating-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(52, 152, 219, 0.6);
        }

        .floating-btn i {
            font-size: 24px;
        }

        .ui-autocomplete {
            max-height: 200px;
            overflow-y: auto;
            overflow-x: hidden;
            z-index: 9999;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .ui-menu-item {
            padding: 10px 15px;
            border-bottom: 1px solid #eee;
        }

        .ui-menu-item:last-child {
            border-bottom: none;
        }

        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            .card-body {
                padding: 20px;
            }
            
            .table th, .table td {
                padding: 12px 10px;
            }
        }

        @media (max-width: 768px) {
            .action-buttons {
                flex-direction: column;
                gap: 10px;
            }
            
            .action-buttons .btn {
                width: 100%;
            }
            
            .floating-btn {
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
            }
        }

        @media (max-width: 576px) {
            .card-header {
                flex-direction: column;
                text-align: center;
                gap: 10px;
            }
            
            .table-responsive {
                margin-top: 10px;
            }
            
            .btn {
                padding: 8px 16px;
            }
            
            .page-container {
                padding: 0 10px;
            }
        }

        /* Animation for row addition */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-row {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <div class="page-container">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-boxes"></i> Add Stock</h2>
                <a href="../../index.php" class="btn btn-light"><i class="fas fa-arrow-left me-2"></i>Back to Dashboard</a>
            </div>
            <div class="card-body">
                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="stockForm">
                    <div class="row mb-4">
                        <div class="col-md-6 offset-md-3">
                            <label for="date" class="form-label">Select Date</label>
                            <div class="date-container">
                                <input type="date" class="form-control form-control-lg" id="date" name="date" required>
                                <i class="far fa-calendar-alt"></i>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table" id="stockTable">
                            <thead>
                                <tr>
                                    <th width="40%">Product Name</th>
                                    <th width="25%">Quantity</th>
                                    <th width="25%">Rate (₹)</th>
                                    <th width="10%">Action</th>
                                </tr>
                            </thead>
                            <tbody id="stock_entries">
                                <tr class="stock-row animate-row">
                                    <td>
                                        <div class="product-input-group">
                                            <input type="text" class="form-control product_name_input" name="product_name[]" placeholder="Enter or select product" required>
                                            <i class="fas fa-box"></i>
                                        </div>
                                    </td>
                                    <td>
                                        <input type="number" class="form-control" name="product_quantity[]" placeholder="Qty" min="1" required>
                                    </td>
                                    <td>
                                        <div class="input-group">
                                            <span class="input-group-text">₹</span>
                                            <input type="number" step="0.01" class="form-control" name="product_rate[]" placeholder="0.00" min="0.01" required>
                                        </div>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-danger delete_row" title="Remove"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="action-buttons">
                        <button type="button" class="btn btn-primary" id="add_row">
                            <i class="fas fa-plus me-2"></i>Add Another Product
                        </button>
                        <button type="submit" class="btn btn-success" id="submitBtn">
                            <i class="fas fa-save me-2"></i>Save Stock
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="floating-btn" id="scrollTopBtn" title="Back to top">
        <i class="fas fa-arrow-up"></i>
    </div>

    <div class="toast-container"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script>
        $(document).ready(function() {
            // Set today's date as default
            const today = new Date().toISOString().split('T')[0];
            $('#date').val(today);

            // Show scroll to top button when scrolled down
            $(window).scroll(function() {
                if ($(this).scrollTop() > 300) {
                    $('#scrollTopBtn').fadeIn();
                } else {
                    $('#scrollTopBtn').fadeOut();
                }
            });

            // Scroll to top action
            $('#scrollTopBtn').click(function() {
                $('html, body').animate({scrollTop : 0}, 800);
                return false;
            });

            // Add row with animation
            $("#add_row").on("click", function() {
                var row = `
                    <tr class="stock-row">
                        <td>
                            <div class="product-input-group">
                                <input type="text" class="form-control product_name_input" name="product_name[]" placeholder="Enter or select product" required>
                                <i class="fas fa-box"></i>
                            </div>
                        </td>
                        <td>
                            <input type="number" class="form-control" name="product_quantity[]" placeholder="Qty" min="1" required>
                        </td>
                        <td>
                            <div class="input-group">
                                <span class="input-group-text">₹</span>
                                <input type="number" step="0.01" class="form-control" name="product_rate[]" placeholder="0.00" min="0.01" required>
                            </div>
                        </td>
                        <td>
                            <button type="button" class="btn btn-danger delete_row" title="Remove"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                `;
                const $newRow = $(row).hide();
                $("#stock_entries").append($newRow);
                $newRow.show().addClass('animate-row');
                initAutocomplete();
            });

            // Delete row with animation
            $(document).on("click", ".delete_row", function() {
                const row = $(this).closest("tr");
                
                // Only allow deletion if there's more than one row
                if ($("#stock_entries tr").length > 1) {
                    row.fadeOut(300, function() {
                        $(this).remove();
                    });
                } else {
                    showToast("Cannot delete the last row", "warning");
                }
            });

            // Initialize autocomplete for all product inputs
            function initAutocomplete() {
                $(".product_name_input").autocomplete({
                    source: <?php echo json_encode($product_names); ?>,
                    minLength: 1,
                    select: function(event, ui) {
                        // Optionally, you can fetch additional product info here
                        console.log("Selected: " + ui.item.value);
                    }
                });
            }

            // Initialize autocomplete on page load
            initAutocomplete();

            // Form validation
            $("#stockForm").on("submit", function(e) {
                let isValid = true;
                const products = new Set();
                
                $(".product_name_input").each(function() {
                    const product = $(this).val().trim();
                    
                    if (product === "") {
                        isValid = false;
                        $(this).addClass("is-invalid");
                        showToast("Please enter all product names", "danger");
                        return false;
                    }
                    
                    if (products.has(product)) {
                        isValid = false;
                        $(this).addClass("is-invalid");
                        showToast("Duplicate product: " + product, "danger");
                        return false;
                    }
                    
                    products.add(product);
                    $(this).removeClass("is-invalid");
                });
                
                if (!isValid) {
                    e.preventDefault();
                } else {
                    // Show loading state
                    $("#submitBtn").html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');
                    $("#submitBtn").prop("disabled", true);
                }
            });

            // Toast notification function
            function showToast(message, type = "info") {
                const toastId = "toast-" + Date.now();
                const toast = `
                    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true" id="${toastId}">
                        <div class="toast-header bg-${type} text-white">
                            <strong class="me-auto">
                                <i class="fas fa-${type === 'danger' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
                                Notification
                            </strong>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            ${message}
                        </div>
                    </div>
                `;
                
                $(".toast-container").append(toast);
                const toastElement = new bootstrap.Toast(document.getElementById(toastId), {
                    delay: 3000
                });
                toastElement.show();
                
                // Remove toast from DOM after it's hidden
                $(`#${toastId}`).on('hidden.bs.toast', function() {
                    $(this).remove();
                });
            }
        });
    </script>
</body>
</html>