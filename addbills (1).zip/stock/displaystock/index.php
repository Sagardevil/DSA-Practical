<?php
include('../../auth.php');
check_login();
// Rest of the code...
?>

<?php
// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all products from list_of_products table and order by quantity in descending order (high to low)
$sql = "SELECT * FROM list_of_products";
$result = $conn->query($sql);
$products = array();
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

// Function to delete a product from list_of_products table
function deleteProduct($conn, $product_id)
{
    $product_id = $conn->real_escape_string($product_id);
    $sql = "DELETE FROM list_of_products WHERE product_id = $product_id";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Function to get product details by ID
function getProductByID($conn, $product_id)
{
    $product_id = $conn->real_escape_string($product_id);
    $sql = "SELECT * FROM list_of_products WHERE product_id = $product_id";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

// Handle AJAX delete request
if (isset($_POST['ajax_delete']) && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $success = deleteProduct($conn, $product_id);
    
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Inventory</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --success-color: #06d6a0;
            --warning-color: #ffd166;
            --danger-color: #ef476f;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --background-color: #f0f2f5;
        }
        
        body {
            background-color: var(--background-color);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-bottom: 40px;
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            padding: 30px 0;
            margin-bottom: 30px;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title {
            font-weight: 700;
            margin: 0;
            font-size: 28px;
        }
        
        .product-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            border: none;
            padding: 20px;
        }
        
        .table-container {
            background-color: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .dataTables_wrapper .dataTables_filter input {
            border-radius: 8px;
            border: 1px solid #ced4da;
            padding: 8px 12px;
            margin-left: 8px;
        }
        
        .dataTables_wrapper .dataTables_length select {
            border-radius: 8px;
            border: 1px solid #ced4da;
            padding: 5px 10px;
        }
        
        .table thead th {
            background-color: rgba(67, 97, 238, 0.1);
            border: none;
            padding: 15px 10px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .table tbody tr {
            border-bottom: 1px solid #e9ecef;
            transition: background-color 0.2s;
        }
        
        .table tbody tr:hover {
            background-color: rgba(67, 97, 238, 0.03);
        }
        
        .table td {
            padding: 15px 10px;
            vertical-align: middle;
        }
        
        .btn-action {
            border-radius: 8px;
            padding: 8px 15px;
            margin: 0 3px;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .btn-blue {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            border: none;
            color: white;
        }
        
        .btn-blue:hover {
            background: linear-gradient(135deg, var(--accent-color), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
        }
        
        .btn-red {
            background: linear-gradient(135deg, var(--danger-color), #ff758f);
            border: none;
            color: white;
        }
        
        .btn-red:hover {
            background: linear-gradient(135deg, #ff758f, var(--danger-color));
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(239, 71, 111, 0.3);
        }
        
        .btn-green {
            background: linear-gradient(135deg, var(--success-color), #8aecc5);
            border: none;
            color: white;
        }
        
        .btn-green:hover {
            background: linear-gradient(135deg, #8aecc5, var(--success-color));
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(6, 214, 160, 0.3);
        }
        
        .badge {
            padding: 8px 12px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.85em;
        }
        
        .badge-quantity {
            background-color: rgba(67, 97, 238, 0.1);
            color: var(--primary-color);
        }
        
        .badge-rate {
            background-color: rgba(6, 214, 160, 0.1);
            color: var(--success-color);
        }
        
        .stock-status {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        
        .status-in-stock {
            background-color: var(--success-color);
        }
        
        .status-low-stock {
            background-color: var(--warning-color);
        }
        
        .status-out-of-stock {
            background-color: var(--danger-color);
        }
        
        .action-btn-container {
            display: flex;
            justify-content: center;
            gap: 8px;
        }
        
        .float-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 4px 20px rgba(67, 97, 238, 0.4);
            transition: all 0.3s;
            z-index: 100;
        }
        
        .float-btn:hover {
            transform: translateY(-5px) rotate(90deg);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.5);
        }
        
        @media (max-width: 768px) {
            .card-header {
                padding: 15px;
            }
            
            .page-header {
                padding: 20px 0;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .table-container {
                padding: 15px 10px;
            }
            
            .action-btn-container {
                flex-direction: column;
                gap: 5px;
            }
            
            .btn-action {
                padding: 6px 10px;
                font-size: 0.9em;
                width: 100%;
            }
            
            .badge {
                padding: 5px 8px;
            }
        }
    </style>
</head>
<body>
    <div class="page-header">
        <div class="container">
            <div class="header-container">
                <h1 class="page-title">
                    <i class="fas fa-boxes me-2"></i>Product Inventory
                </h1>
                <a href="../addproduct/index.php" class="btn btn-light d-none d-md-inline-block">
                    <i class="fas fa-plus me-2"></i>Add New Product
                </a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="table-container">
                    <table id="products-table" class="table table-hover">
                        <thead>
                            <tr>
                                <th width="5%">#</th>
                                <th width="30%">Product Name</th>
                                <th width="15%">Quantity</th>
                                <th width="15%">Rate</th>
                                <th width="20%">Status</th>
                                <th width="15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $index => $product): ?>
                                <?php 
                                    $stockStatus = '';
                                    $stockStatusClass = '';
                                    $quantity = $product['quantity'];
                                    
                                    if ($quantity <= 0) {
                                        $stockStatus = 'Out of Stock';
                                        $stockStatusClass = 'status-out-of-stock';
                                    } else if ($quantity < 10) {
                                        $stockStatus = 'Low Stock';
                                        $stockStatusClass = 'status-low-stock';
                                    } else {
                                        $stockStatus = 'In Stock';
                                        $stockStatusClass = 'status-in-stock';
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td class="fw-medium"><?php echo htmlspecialchars($product['product_name']); ?></td>
                                    <td>
                                        <span class="badge badge-quantity">
                                            <?php echo $product['quantity'] ?? 'N/A'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-rate">
                                            ₹<?php echo number_format($product['product_rate'], 2); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="stock-status <?php echo $stockStatusClass; ?>"></span>
                                        <?php echo $stockStatus; ?>
                                    </td>
                                    <td>
                                        <div class="action-btn-container">
                                            <a href="update_product.php?id=<?php echo $product['product_id']; ?>" class="btn btn-action btn-blue btn-sm">
                                                <i class="fas fa-edit me-1"></i> Edit
                                            </a>
                                            <button class="btn btn-action btn-red btn-sm delete-btn" data-id="<?php echo $product['product_id']; ?>" data-name="<?php echo htmlspecialchars($product['product_name']); ?>">
                                                <i class="fas fa-trash-alt me-1"></i> Delete
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($products)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <div class="text-muted">
                                            <i class="fas fa-box-open fa-3x mb-3"></i>
                                            <p>No products found. Add your first product!</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Floating action button for mobile -->
    <a href="add_product.php" class="float-btn d-md-none">
        <i class="fas fa-plus"></i>
    </a>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap 5 Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            $('#products-table').DataTable({
                responsive: true,
                language: {
                    search: "<i class='fas fa-search'></i> Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ products",
                    infoEmpty: "Showing 0 to 0 of 0 products",
                    infoFiltered: "(filtered from _MAX_ total products)",
                    emptyTable: "No products available",
                    zeroRecords: "No matching products found"
                },
                columnDefs: [
                    { orderable: false, targets: [5] } // Disable sorting on action column
                ],
                order: [] // Remove default sorting to preserve database order
            });

            // Handle delete button click
            $('.delete-btn').on('click', function() {
                const productId = $(this).data('id');
                const productName = $(this).data('name');
                const row = $(this).closest('tr');
                
                Swal.fire({
                    title: 'Delete Product',
                    html: `Are you sure you want to delete <strong>${productName}</strong>?<br>This action cannot be undone.`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ef476f',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Send AJAX request to delete the product
                        $.ajax({
                            url: '<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>',
                            type: 'POST',
                            data: {
                                ajax_delete: true,
                                product_id: productId
                            },
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    // Remove the row from the table
                                    row.fadeOut(400, function() {
                                        const table = $('#products-table').DataTable();
                                        table.row(row).remove().draw();
                                        
                                        Swal.fire(
                                            'Deleted!',
                                            `${productName} has been deleted successfully.`,
                                            'success'
                                        );
                                    });
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        'Failed to delete the product. Please try again.',
                                        'error'
                                    );
                                }
                            },
                            error: function() {
                                Swal.fire(
                                    'Error!',
                                    'An error occurred while processing your request.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>