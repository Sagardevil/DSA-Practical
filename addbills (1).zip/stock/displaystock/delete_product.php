<?php
include('../../auth.php');
check_login();
// Rest of the code...
?>

<?php

// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if product ID is provided in the URL
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Function to delete a product from list_of_products table
    function deleteProduct($conn, $product_id)
    {
        $sql = "DELETE FROM list_of_products WHERE product_id = $product_id";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Product deleted successfully.'); window.location.href = 'index.php';</script>";
        } else {
            echo "Error deleting product: " . $conn->error;
        }
    }

    // Delete the product
    deleteProduct($conn, $product_id);
} else {
    echo "<script>alert('Product ID not provided.'); window.location.href = 'list_products.php';</script>";
}
?>
