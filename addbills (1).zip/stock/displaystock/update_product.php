<?php
include('../../auth.php');
check_login();
// Rest of the code...
?>

<?php

// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if product ID is provided in the URL
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Fetch product details from list_of_products table
    $sql = "SELECT * FROM list_of_products WHERE product_id = $product_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $product_name = $row['product_name'];
        $product_quantity = $row['quantity'];
        $product_rate = $row['product_rate'];
    } else {
        echo "<script>alert('Product not found.'); window.location.href = 'list_products.php';</script>";
    }
} else {
    echo "<script>alert('Product ID not provided.'); window.location.href = 'list_products.php';</script>";
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = $_POST["product_name"];
    $product_quantity = $_POST["product_quantity"];
    $product_rate = $_POST["product_rate"];

    // Update product details in list_of_products table
    $sql = "UPDATE list_of_products SET product_name='$product_name', quantity='$product_quantity', product_rate='$product_rate' WHERE product_id = $product_id";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product updated successfully.'); window.location.href = 'index.php';</script>";
    } else {
        echo "Error updating product: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }

        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">Update Product</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?php echo $product_id; ?>">
            <div class="form-group">
                <label for="product_name">Product Name:</label>
                <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo $product_name; ?>" required>
            </div>
            <div class="form-group">
                <label for="product_quantity">Quantity:</label>
                <input type="number" class="form-control" id="product_quantity" name="product_quantity" value="<?php echo $product_quantity; ?>">
            </div>
            <div class="form-group">
                <label for="product_rate">Rate:</label>
                <input type="number" step="0.01" class="form-control" id="product_rate" name="product_rate" value="<?php echo $product_rate; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>
</body>
</html>
