<?php
include('../../auth.php');
check_login();
// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Get the table name from the URL
if(isset($_GET['table_name'])){
    $table_name = $_GET['table_name'];
    // Extract date from table name
    $date = substr($table_name, 9); // Assuming the table name format is 'stock_of_ddmmyyyy'
    // Format date as 'dd-mm-yyyy'
    $formatted_date = substr($date, 0, 2) . '-' . substr($date, 2, 2) . '-' . substr($date, 4);
    // Fetch data from the specified table
    $sql = "SELECT * FROM $table_name";
    $result = $conn->query($sql);
    $stock_data = array();
    $total_amount = 0;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $stock_data[] = $row;
            // Calculate total amount for each row and add to total amount
            $total_amount += $row['product_quantity'] * $row['product_rate'];
        }
    } else {
        $error_message = "No data found in the selected table.";
    }
} else {
    $error_message = "Table name not provided.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a0ca3;
            --secondary: #4361ee;
            --accent: #4cc9f0;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #2dc653;
            --danger: #e63946;
            --warning: #ffb703;
        }
        
        body {
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
            margin: 0;
        }
        
        .dashboard-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 1200px;
            padding: 2rem;
            margin: 1rem;
            backdrop-filter: blur(10px);
            animation: fadeIn 0.6s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 2px solid var(--accent);
            position: relative;
        }
        
        .header h2 {
            color: var(--primary);
            font-weight: 700;
            margin-bottom: 0.75rem;
            font-size: 2.2rem;
        }
        
        .header .date-badge {
            background: linear-gradient(135deg, var(--secondary), var(--primary));
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            display: inline-block;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
        }
        
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .stock-table {
            margin-bottom: 0;
        }
        
        .stock-table thead th {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            padding: 1rem;
            border: none;
            vertical-align: middle;
        }
        
        .stock-table tbody tr:hover {
            background-color: rgba(76, 201, 240, 0.1);
            transition: background-color 0.3s ease;
        }
        
        .stock-table td {
            padding: 1rem;
            vertical-align: middle;
            border-color: #edf2f7;
        }
        
        .product-name {
            font-weight: 600;
            color: var(--dark);
        }
        
        .quantity-badge {
            background-color: var(--accent);
            color: white;
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
        }
        
        .amount-cell {
            font-weight: 600;
            color: var(--primary);
        }
        
        .update-btn {
            background: linear-gradient(135deg, var(--secondary), var(--primary));
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .update-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
        }
        
        .total-section {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 12px;
            padding: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
        }
        
        .total-label {
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        .total-value {
            font-size: 1.5rem;
            font-weight: 700;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
        }
        
        .currency-symbol {
            margin-right: 0.25rem;
        }
        
        .actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .action-btn {
            padding: 0.75rem 1.5rem;
            border-radius: 50px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .back-btn {
            background-color: var(--dark);
            color: white;
        }
        
        .back-btn:hover {
            background-color: #343a40;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: white;
        }
        
        .print-btn {
            background-color: var(--accent);
            color: white;
        }
        
        .print-btn:hover {
            background-color: #33b8e0;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: white;
        }
        
        .export-btn {
            background-color: var(--success);
            color: white;
        }
        
        .export-btn:hover {
            background-color: #26a746;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: white;
        }
        
        .no-data {
            text-align: center;
            padding: 3rem;
            color: var(--danger);
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1.5rem;
                margin: 0.5rem;
            }
            
            .header h2 {
                font-size: 1.8rem;
            }
            
            .stock-table th, 
            .stock-table td {
                padding: 0.75rem 0.5rem;
                font-size: 0.9rem;
            }
            
            .total-section {
                flex-direction: column;
                gap: 0.5rem;
                text-align: center;
                padding: 1rem;
            }
            
            .total-value {
                font-size: 1.3rem;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
            }
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
                margin: 0;
            }
            
            .dashboard-container {
                box-shadow: none;
                margin: 0;
                padding: 1rem;
                max-width: 100%;
                width: 100%;
            }
            
            .actions {
                display: none;
            }
            
            .update-btn {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2><i class="fas fa-boxes me-2"></i>Stock Inventory</h2>
            <div class="date-badge">
                <i class="far fa-calendar-alt me-2"></i><?php echo $formatted_date; ?>
            </div>
        </div>
        
        <?php if (isset($error_message)): ?>
            <div class="no-data">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo $error_message; ?>
            </div>
        <?php else: ?>
            <div class="table-container">
                <div class="table-responsive">
                    <table class="table stock-table">
                        <thead>
                            <tr>
                                <th class="d-none d-md-table-cell"><i class="fas fa-hashtag me-1"></i> ID</th>
                                <th><i class="fas fa-box me-1"></i> Product</th>
                                <th><i class="fas fa-cubes me-1"></i> Qty</th>
                                <th><i class="fas fa-tag me-1"></i> Rate</th>
                                <th><i class="fas fa-calculator me-1"></i> Amount</th>
                                <th><i class="fas fa-edit me-1"></i> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stock_data as $row): ?>
                                <tr>
                                    <td class="d-none d-md-table-cell"><?php echo $row['id']; ?></td>
                                    <td class="product-name"><?php echo $row['product_name']; ?></td>
                                    <td><span class="quantity-badge"><?php echo $row['product_quantity']; ?></span></td>
                                    <td><span class="currency-symbol">₹</span><?php echo number_format($row['product_rate'], 2); ?></td>
                                    <td class="amount-cell"><span class="currency-symbol">₹</span><?php echo number_format($row['product_quantity'] * $row['product_rate'], 2); ?></td>
                                    <td><a href="update_product.php?product_name=<?php echo urlencode($row['product_name']); ?>&table_name=<?php echo urlencode($table_name); ?>" class="update-btn"><i class="fas fa-pen me-1"></i> Update</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="total-section">
                <div class="total-label"><i class="fas fa-money-bill-wave me-2"></i>Total Inventory Value</div>
                <div class="total-value"><span class="currency-symbol">₹</span><?php echo number_format($total_amount, 2); ?></div>
            </div>
            
            <div class="actions">
                <a href="../../index.php" class="action-btn back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <a href="javascript:window.print()" class="action-btn print-btn"><i class="fas fa-print"></i> Print Inventory</a>
                <a href="#" class="action-btn export-btn"><i class="fas fa-file-export"></i> Export to Excel</a>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>