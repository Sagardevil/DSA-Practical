<?php
include('../../auth.php');
check_login();

// Database connection
include '../../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ensure that the necessary POST parameters are set
    if(isset($_POST['product_name']) && isset($_POST['product_quantity']) && isset($_POST['table_name'])){
        $product_name = $_POST['product_name'];
        $new_quantity = intval($_POST['product_quantity']);
        $table_name = $_POST['table_name'];
        
        // Fetch the old quantity from the specified table
        $fetch_old_quantity_query = "SELECT product_quantity FROM $table_name WHERE product_name = ?";
        $stmt = $conn->prepare($fetch_old_quantity_query);
        if ($stmt) {
            $stmt->bind_param('s', $product_name);
            $stmt->execute();
            $stmt->bind_result($old_quantity);
            $stmt->fetch();
            $stmt->close();

            // Update the quantity in the specified table
            $update_stock_query = "UPDATE $table_name SET product_quantity = ? WHERE product_name = ?";
            $stmt = $conn->prepare($update_stock_query);
            if ($stmt) {
                $stmt->bind_param('is', $new_quantity, $product_name);
                $stmt->execute();
                $stmt->close();

                // Calculate the difference and update the 'list_of_products' table
                $difference = $new_quantity - $old_quantity;
                if ($difference != 0) {
                    $update_list_query = "UPDATE list_of_products SET quantity = quantity + ? WHERE product_name = ?";
                    $stmt = $conn->prepare($update_list_query);
                    if ($stmt) {
                        $stmt->bind_param('is', $difference, $product_name);
                        $stmt->execute();
                        $stmt->close();
                    }
                }

                echo "<script>alert('Product updated successfully!'); window.location='index.php?table_name=$table_name';</script>";
            } else {
                echo "Error preparing update query: " . $conn->error;
            }
        } else {
            echo "Error preparing fetch query: " . $conn->error;
        }
    } else {
        echo "Product name, quantity, or table name not provided.";
    }
} else {
    // Display the update form
    if (isset($_GET['product_name']) && isset($_GET['table_name'])) {
        $product_name = $_GET['product_name'];
        $table_name = $_GET['table_name'];
        
        // Fetch the current values of the product
        $query = "SELECT product_name, product_quantity, product_rate FROM $table_name WHERE product_name = ?";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param('s', $product_name);
            $stmt->execute();
            $stmt->bind_result($product_name, $product_quantity, $product_rate);
            $stmt->fetch();
            $stmt->close();
        } else {
            echo "Error preparing fetch query: " . $conn->error;
        }
    } else {
        echo "Product name or table name not provided.";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="text-center">Update Product</h2>
        <form method="POST" action="update_product.php">
            <input type="hidden" name="table_name" value="<?php echo $table_name; ?>">
            <div class="form-group">
                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" class="form-control" value="<?php echo $product_name; ?>" readonly>
            </div>
            <div class="form-group">
                <label for="product_quantity">Quantity:</label>
                <input type="number" id="product_quantity" name="product_quantity" class="form-control" value="<?php echo $product_quantity; ?>" required>
            </div>
            <div class="form-group">
                <label for="product_rate">Rate:</label>
                <input type="number" id="product_rate" name="product_rate" class="form-control" value="<?php echo $product_rate; ?>" readonly>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</body>
</html>
