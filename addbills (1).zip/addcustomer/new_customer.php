<?php
include('../auth.php');
check_login();
// Rest of the code...
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Customer - Tirupati Sales</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border: none;
        }

        .card-header {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            text-align: center;
            padding: 20px;
            border-bottom: none;
        }

        .card-body {
            padding: 30px;
        }

        h2 {
            margin-bottom: 0;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-label {
            font-weight: 500;
            color: #495057;
            margin-bottom: 8px;
        }

        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.25);
            border-color: #80bdff;
        }

        .input-icon {
            position: absolute;
            right: 15px;
            top: 45px;
            color: #6c757d;
        }

        .btn-primary {
            background: linear-gradient(135deg, #007bff, #0056b3);
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all 0.3s;
            width: 100%;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.4);
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
            text-decoration: none;
        }

        .back-link:hover {
            color: #007bff;
        }

        /* Responsive adjustments */
        @media (max-width: 576px) {
            .card-body {
                padding: 20px;
            }
            
            .card {
                margin: 0 10px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-user-plus me-2"></i>Add New Customer</h2>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                            <div class="form-group">
                                <label for="customer_name" class="form-label">Customer Name</label>
                                <div class="position-relative">
                                    <input type="text" class="form-control" id="customer_name" name="customer_name" placeholder="Enter customer name" required>
                                    <i class="fas fa-user input-icon"></i>
                                </div>
                                <div class="invalid-feedback">
                                    Please provide a customer name.
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="phone_number" class="form-label">Phone Number</label>
                                <div class="position-relative">
                                    <input type="tel" class="form-control" id="phone_number" name="phone_number" placeholder="Enter phone number" required>
                                    <i class="fas fa-phone input-icon"></i>
                                </div>
                                <div class="invalid-feedback">
                                    Please provide a valid phone number.
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="initial_amount" class="form-label">Initial Amount</label>
                                <div class="position-relative">
                                    <input type="number" step="0.01" class="form-control" id="initial_amount" name="initial_amount" placeholder="Enter initial amount" required>
                                    <i class="fas fa-rupee-sign input-icon"></i>
                                </div>
                                <div class="invalid-feedback">
                                    Please provide an initial amount.
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Add Customer
                            </button>
                        </form>
                        
                        <a href="../index.php" class="back-link">
                            <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation script
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
                
                // Add phone number validation
                var phoneInput = document.getElementById('phone_number');
                phoneInput.addEventListener('input', function() {
                    this.value = this.value.replace(/[^0-9]/g, '');
                });
            }, false);
        })();
    </script>
</body>

</html>
<?php

// Database connection
include '../conn.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $customer_name = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $initial_amount = floatval($_POST['initial_amount']);
    $current_date = date("Y-m-d");

    // Prepare SQL statement to insert customer data into list_of_customers table
    $insert_customer_sql = "INSERT INTO list_of_customers (customer_name, phone) VALUES ('$customer_name', '$phone_number')";

    // Execute SQL statement
    if ($conn->query($insert_customer_sql) === TRUE) {
        // Create table for customer amount if it doesn't exist
        $table_name = str_replace(' ', '_', $customer_name) . '_amount';
        $create_table_sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            amount DECIMAL(10, 2) NOT NULL,
            paid_received TINYINT(1) DEFAULT 1,
            transaction_date DATE,
            payment VARCHAR(100)
        )";

        // Execute SQL statement
        if ($conn->query($create_table_sql) === TRUE) {
            // Insert initial amount into the customer's amount table
            $insert_amount_sql = "INSERT INTO $table_name (amount, transaction_date) VALUES ('$initial_amount', '$current_date')";
            if ($conn->query($insert_amount_sql) === TRUE) {
                // Display popup message and redirect to index.php
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "Success!",
                        text: "Customer added successfully",
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        window.location.href = "../index.php";
                    });
                </script>';
            } else {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: "Error inserting amount: ' . $conn->error . '",
                    });
                </script>';
            }
        } else {
            echo '<script>
                Swal.fire({
                    icon: "error",
                    title: "Error!",
                    text: "Error creating table: ' . $conn->error . '",
                });
            </script>';
        }
    } else {
        echo '<script>
            Swal.fire({
                icon: "error",
                title: "Error!",
                text: "Error: ' . $conn->error . '",
            });
        </script>';
    }
}

$conn->close();
?>