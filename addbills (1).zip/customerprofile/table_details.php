    <?php
    session_start();

    // Include database connection
    include "../conn.php";

    // Check if user is logged in
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        header("Location: ../login.php");
        exit();
    }

    // Check if table name is provided in the URL
    if (!isset($_GET['table_name']) || empty($_GET['table_name'])) {
        header("Location: ../index.php");
        exit();
    }

    $table_name = $_GET['table_name'];
    $customer_name = str_replace('_', ' ', $table_name);
    $date = substr($customer_name, -8);
    $customer_name_without_date = substr($customer_name, 0, -8);

    // Fetch data from the specified table
    $sql = "SELECT * FROM $table_name";
    $result = $conn->query($sql);
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bill Details</title>
        <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
        <style>
            :root {
                --primary: #4361ee;
                --secondary: #3f37c9;
                --accent: #4895ef;
                --light: #f8f9fa;
                --dark: #212529;
                --success: #4cc9f0;
                --danger: #f72585;
            }

            body {
                background: linear-gradient(135deg, var(--primary), var(--accent));
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
                min-height: 100vh;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .container {
                max-width: 95%;
                margin: 2rem auto;
                background: rgba(255, 255, 255, 0.95);
                padding: 2rem;
                border-radius: 16px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
                backdrop-filter: blur(10px);
                animation: fadeIn 0.5s ease-in-out;
                transition: all 0.3s ease;
            }

            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }

            .header {
                text-align: center;
                margin-bottom: 2rem;
                padding-bottom: 1rem;
                border-bottom: 2px solid var(--accent);
            }

            h2 {
                color: var(--primary);
                font-weight: 700;
                margin-bottom: 0.5rem;
            }

            h3 {
                color: var(--secondary);
                font-weight: 600;
                margin-bottom: 0.5rem;
            }

            h4 {
                color: var(--dark);
                font-weight: 500;
                margin-bottom: 1.5rem;
            }

            .table-responsive {
                overflow-x: auto;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            }

            .table {
                margin-bottom: 0;
                white-space: nowrap;
            }

            .table thead th {
                background-color: var(--primary);
                color: white;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                padding: 1rem;
                vertical-align: middle;
                border: none;
            }

            .table tbody tr:nth-child(even) {
                background-color: rgba(67, 97, 238, 0.05);
            }

            .table tbody tr:hover {
                background-color: rgba(67, 97, 238, 0.1);
                transition: background-color 0.3s ease;
            }

            .table td {
                padding: 1rem;
                vertical-align: middle;
            }

            .no-data {
                text-align: center;
                font-weight: bold;
                color: var(--danger);
                padding: 2rem;
            }

            .update-btn {
                display: inline-block;
                color: white;
                background-color: var(--success);
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 50px;
                transition: all 0.3s ease;
                text-decoration: none;
                font-weight: 500;
            }

            .update-btn:hover {
                background-color: var(--secondary);
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            .icon {
                margin-right: 8px;
            }

            .total-row {
                background-color: rgba(67, 97, 238, 0.1) !important;
                font-weight: bold;
                font-size: 1.1rem;
            }

            .total-row td {
                border-top: 2px solid var(--accent);
            }

            .action-btn {
                display: inline-block;
                color: white;
                padding: 0.75rem 1.5rem;
                border-radius: 50px;
                text-decoration: none;
                transition: all 0.3s ease;
                margin-top: 1.5rem;
                font-weight: 500;
                border: none;
                cursor: pointer;
            }

            .back-btn {
                background-color: var(--dark);
            }

            .print-btn {
                background-color: var(--accent);
            }

            .pdf-btn {
                background-color: #e74c3c;
            }

            .action-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                color: white;
                text-decoration: none;
            }

            .currency {
                font-family: 'Courier New', monospace;
                font-weight: 600;
            }

            .actions {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-top: 1.5rem;
                gap: 1rem;
                flex-wrap: wrap;
            }

            @media (max-width: 768px) {
                .container {
                    padding: 1rem;
                    margin: 1rem;
                }

                .table td, .table th {
                    padding: 0.75rem 0.5rem;
                    font-size: 0.9rem;
                }

                .header {
                    margin-bottom: 1rem;
                }

                h2 {
                    font-size: 1.5rem;
                }

                h3 {
                    font-size: 1.2rem;
                }

                h4 {
                    font-size: 1rem;
                }

                .actions {
                    flex-direction: column;
                }

                .action-btn {
                    width: 100%;
                    text-align: center;
                }
            }

            @media print {
                body {
                    background: none;
                }
                
                .container {
                    box-shadow: none;
                    max-width: 100%;
                    margin: 0;
                    padding: 1rem;
                }
                
                .actions, .update-btn {
                    display: none;
                }
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div class="header">
                <h2><i class="fas fa-file-invoice icon"></i>Bill Details</h2>
                <h3><i class='fas fa-user icon'></i><?php echo $customer_name_without_date; ?></h3>
                <h4><i class='far fa-calendar-alt icon'></i>Date: <?php echo $date; ?></h4>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered" id="billTable">
                    <thead>
                        <tr>
                            <th><i class="fas fa-hashtag icon"></i>Sr.No</th>
                            <th><i class="fas fa-box icon"></i>Product</th>
                            <th><i class="fas fa-sort-numeric-up icon"></i>Qty</th>
                            <th><i class="fas fa-rupee-sign icon"></i>Price</th>
                            <th><i class="fas fa-calculator icon"></i>Amount</th>
                            <th><i class="fas fa-edit icon"></i>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            $ccid = 1;
                            $amount = 0;
                            $total = 0;
                            while ($row = $result->fetch_assoc()) {
                                $amount = $row['quantity'] * $row['price'];
                                echo "<tr>";
                                echo "<td>$ccid</td>";
                                echo "<td>{$row['productName']}</td>";
                                echo "<td>{$row['quantity']}</td>";
                                echo "<td class='currency'>&#8377;{$row['price']}</td>";
                                echo "<td class='currency'>&#8377;$amount</td>";
                                echo "<td><a href='update_product.php?productName={$row['productName']}&tableName=$table_name' class='update-btn'><i class='fas fa-pen'></i> Edit</a></td>";
                                echo "</tr>";
                                $total += $amount;
                                $ccid++;
                            }
                            echo "<tr class='total-row'>";
                            echo "<td colspan='4'><i class='fas fa-money-bill-wave icon'></i>Total Bill:</td>";
                            echo "<td colspan='2' class='currency'>&#8377;$total</td>";
                            echo "</tr>";
                        } else {
                            echo "<tr><td colspan='6' class='no-data'><i class='fas fa-exclamation-circle icon'></i>No data found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div class="actions">
                <a href="../index.php" class="action-btn back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <div>
                    <button onclick="exportToPDF()" class="action-btn pdf-btn"><i class="fas fa-file-pdf"></i> Export PDF</button>
                    <a href="javascript:window.print()" class="action-btn print-btn"><i class="fas fa-print"></i> Print Bill</a>
                </div>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
        
      <script>
function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Get table data first to determine page requirements
    const table = document.getElementById("billTable");
    const rows = [];
    let subtotal = 0;
    
    for (let i = 1; i < table.rows.length - 1; i++) {
        const row = table.rows[i];
        const product = row.cells[1].innerText.trim();
        const qty = parseFloat(row.cells[2].innerText.trim());
        const price = parseFloat(row.cells[3].innerText.replace(/[^\d.-]/g, ''));
        const amount = parseFloat(row.cells[4].innerText.replace(/[^\d.-]/g, ''));
        
        rows.push({
            slNo: i,
            product: product,
            qty: qty,
            price: price,
            amount: amount
        });
        
        subtotal += amount;
    }
    
    // Calculate grand total (no GST as requested)
    const grandTotal = subtotal;
    
    // Generate random data
    const today = new Date();
    const formattedDate = today.getDate() + "-" + 
                         (today.getMonth() + 1).toString().padStart(2, '0') + "-" + 
                         today.getFullYear().toString().substr(-2);
    const invoiceNo = "2526-TS-" + Math.floor(Math.random() * 100).toString().padStart(2, '0');
    const refNo = "REF" + Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const buyerOrderNo = "ORD" + Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    
    function addHeader(doc) {
        // Set title - without the "Printed on" and "ORIGINAL FOR RECIPIENT" text
        doc.setFont("helvetica", "bold");
        doc.setFontSize(16);
        doc.setTextColor(0, 0, 0);
        doc.text("GST TAX INVOICE", 105, 15, { align: 'center' });
    
        // Draw border for company details
        doc.rect(14, 20, 125, 40);
        
        // Company details (left box)
        doc.setFontSize(11);
        doc.setFont("helvetica", "bold");
        doc.text("TIRUPATI SALES", 16, 25);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        doc.text("Behind Kathale Vihar", 16, 30);
        doc.text("Barshi - 413401", 16, 35);
        doc.text("District : Solapur", 16, 40);
        doc.text("State : Maharashtra, Code : 27", 16, 45);
        doc.text("GSTIN/UIN: ", 16, 50);
        doc.text("E-Mail : tirupatisales@gmail.com", 16, 55);
    
        // Draw border for invoice details
        doc.rect(139, 20, 57, 40);
        
        // Invoice details (right box) - ensuring proper positioning
        const leftCol = 141;
        const rightCol = 170;
        const lineHeight = 6;
        let yPos = 25;
        
        // Row 1
        doc.setFontSize(8);
        doc.text("Invoice No", leftCol, yPos);
        doc.text("Dated", rightCol, yPos);
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight - 1;
        doc.setFont("helvetica", "bold");
        doc.text(invoiceNo, leftCol, yPos);
        doc.text(formattedDate, rightCol, yPos);
        doc.setFont("helvetica", "normal");
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight;
        
        // Row 2
        doc.text("Delivery Note", leftCol, yPos);
        doc.text("Mode/Terms of Payment", rightCol, yPos);
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight;
        
        // Row 3
        doc.text("Reference No. & Date.", leftCol, yPos);
        doc.text("Other References", rightCol, yPos);
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight - 1;
        doc.text(refNo + " dt. " + formattedDate, leftCol, yPos);
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight;
        
        // Row 4
        doc.text("Buyer's Order No.", leftCol, yPos);
        doc.text("Dated", rightCol, yPos);
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight - 1;
        doc.text(buyerOrderNo, leftCol, yPos);
        doc.line(139, yPos + 1, 196, yPos + 1);
        yPos += lineHeight;
        
        // Row 5
       
        
        // Draw border for buyer details (reduced height)
        doc.rect(14, 65, 182, 25);
        
        // Buyer details
        doc.setFont("helvetica", "bold");
        doc.text("Buyer (Bill to)", 16, 70);
        doc.setFont("helvetica", "bold");
        doc.text("Prem Ratan Enterprises", 16, 76);
        doc.setFont("helvetica", "normal");
        doc.text("State Name: Maharashtra", 16, 82);
    }
    
    function addTableHeader(doc, yPos) {
        // Draw table headers with full grid
        doc.setFillColor(240, 240, 240);
        doc.rect(14, yPos, 182, 10, 'F');
        
        // Vertical lines
        doc.line(25, yPos, 25, yPos + 10); // Sl No. column
        doc.line(120, yPos, 120, yPos + 10); // Description column
        doc.line(150, yPos, 150, yPos + 10); // Quantity column
        doc.line(170, yPos, 170, yPos + 10); // Rate column
        
        // Horizontal lines
        doc.line(14, yPos, 196, yPos); // Top line
        doc.line(14, yPos + 10, 196, yPos + 10); // Bottom line
        
        // Header text
        doc.setFont("helvetica", "bold");
        doc.text("Sl No.", 20, yPos + 7, { align: 'center' });
        doc.text("Description of Goods", 70, yPos + 7, { align: 'center' });
        doc.text("Quantity", 135, yPos + 7);
        doc.text("Rate", 160, yPos + 7);
        doc.text("Amount", 190, yPos + 7, { align: 'right' });
        
        return yPos + 10; // Return the new Y position
    }
    
    // Add header
    addHeader(doc);
    
    // Add table header starting at y=95
    let startY = 95;
    startY = addTableHeader(doc, startY);
    
    // Add table data
    const itemsPerPage = 20; // Adjust based on your needs
    let currentPage = 1;
    let itemsOnCurrentPage = 0;
    
    for (let i = 0; i < rows.length; i++) {
        // Check if we need a new page
        if (itemsOnCurrentPage >= itemsPerPage) {
            doc.addPage();
            addHeader(doc);
            startY = 95;
            startY = addTableHeader(doc, startY);
            itemsOnCurrentPage = 0;
            currentPage++;
        }
        
        const item = rows[i];
        
        // Draw vertical lines for each row
        doc.line(14, startY, 14, startY + 7); // Left border
        doc.line(25, startY, 25, startY + 7); // Sl No. column
        doc.line(120, startY, 120, startY + 7); // Description column
        doc.line(150, startY, 150, startY + 7); // Quantity column
        doc.line(170, startY, 170, startY + 7); // Rate column
        doc.line(196, startY, 196, startY + 7); // Right border
        
        // Add content
        doc.setFont("helvetica", "normal");
        doc.text(item.slNo.toString(), 20, startY + 5, { align: 'center' });
        
        // Split long product names into multiple lines if needed
        const maxProductWidth = 90; // Max width for product description
        const productLines = doc.splitTextToSize(item.product, maxProductWidth);
        doc.text(productLines, 28, startY + 5);
        
        doc.text(item.qty.toFixed(1) + " nos", 135, startY + 5);
        doc.text(item.price.toFixed(2), 160, startY + 5);
        doc.text(item.amount.toFixed(2), 190, startY + 5, { align: 'right' });
        
        // Draw horizontal line
        doc.line(14, startY + 7, 196, startY + 7);
        
        // Adjust Y position based on number of product lines
        startY += (productLines.length > 1 ? (productLines.length * 5) : 7);
        itemsOnCurrentPage++;
    }
    
    // Add summary at the bottom
    startY += 10;
    
    // If there's not enough space for summary on the current page, add a new page
    if (startY > 240) {
        doc.addPage();
        addHeader(doc);
        startY = 95;
    }
    
    // Draw line separator
    doc.line(14, startY, 196, startY);
    
    // Display subtotal - aligned to the right
    startY += 10;
    doc.setFont("helvetica", "normal");
    doc.text("Total", 160, startY);
    doc.text(subtotal.toFixed(2), 190, startY, { align: 'right' });
    
    // Display grand total
    startY += 10;
    doc.setFont("helvetica", "bold");
    doc.text("Total : ", 160, startY);
    doc.text(" " + grandTotal.toFixed(2), 190, startY, { align: 'right' });
    
    // Amount in words
    startY += 10;
    doc.setFont("helvetica", "normal");
    doc.text("Amount Chargeable (in words)", 16, startY-20);
    startY += 5;
    doc.setFont("helvetica", "bold");
    const amountInWords = "INR " + numberToWords(Math.round(grandTotal)) + " Only";
    const wordsLines = doc.splitTextToSize(amountInWords, 180);
    doc.text(wordsLines, 16, startY-20);
    startY += (wordsLines.length * 5) + 5;
    
    // Reorganized footer to avoid overlapping
    // Create clear spacing for footer sections
    const leftFooterX = 16;
    const rightFooterX = 160;
    let footerY = Math.min(startY + 15, 240); // Lower max value to avoid page bottom
    
    // Declaration box (left side)
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text("Declaration", leftFooterX, footerY);
    doc.text("We declare that this invoice shows the actual price of", leftFooterX, footerY + 5);
    doc.text("the goods described and that all particulars are true", leftFooterX, footerY + 10);
    doc.text("and correct.", leftFooterX, footerY + 15);
    
    // Signature box (right side)
    doc.text("", rightFooterX, footerY);
    doc.text("Authorised Signatory", rightFooterX, footerY + 25);
    
    // Final footer texts - placed lower
    footerY = 260; // Fixed position for page info
    
    // Add page number info if multiple pages
    if (currentPage > 1) {
        for (let i = 1; i <= currentPage; i++) {
            doc.setPage(i);
            doc.text("Page " + i + " of " + currentPage, 105, footerY, { align: 'center' });
        }
    }
    
    // Set final page for footer text
    doc.setPage(currentPage);
    doc.text("SUBJECT TO BARSHI JURISDICTION", 105, footerY + 5, { align: 'center' });
    doc.text("This is a Computer Generated Invoice", 105, footerY + 10, { align: 'center' });
    
    // Save the PDF
    doc.save("TirupatiSales_<?php echo $customer_name_without_date . '_' . $date; ?>.pdf");
}

// Helper function to convert numbers to words
function numberToWords(num) {
    const single = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
    const double = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    const formatTens = (num) => {
        if (num < 10) return single[num];
        else if (num < 20) return double[num - 10];
        else {
            return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + single[num % 10] : '');
        }
    };
    
    if (num === 0) return 'Zero';
    
    let words = '';
    
    if (Math.floor(num / 10000000) > 0) {
        words += numberToWords(Math.floor(num / 10000000)) + ' Crore ';
        num %= 10000000;
    }
    
    if (Math.floor(num / 100000) > 0) {
        words += numberToWords(Math.floor(num / 100000)) + ' Lakh ';
        num %= 100000;
    }
    
    if (Math.floor(num / 1000) > 0) {
        words += numberToWords(Math.floor(num / 1000)) + ' Thousand ';
        num %= 1000;
    }
    
    if (Math.floor(num / 100) > 0) {
        words += numberToWords(Math.floor(num / 100)) + ' Hundred ';
        num %= 100;
    }
    
    if (num > 0) {
        words += formatTens(num);
    }
    
    return words.trim();
}
</script>
    </body>
    </html>