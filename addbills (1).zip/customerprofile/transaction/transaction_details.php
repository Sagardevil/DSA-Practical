<?php
session_start();

// Include database connection
include "../../conn.php";

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../login.php");
    exit();
}

// Check if transaction ID and customer name are provided in the URL
if (!isset($_GET['transaction_id']) || empty($_GET['transaction_id']) || !isset($_GET['customer_name']) || empty($_GET['customer_name'])) {
    header("Location: ../index.php");
    exit();
}

// Fetch transaction ID and customer name from the URL
$transaction_id = $_GET['transaction_id'];
$customer_name = $_GET['customer_name'];

// Fetch transaction details from the database
$sql_transaction = "SELECT * FROM $customer_name WHERE id = $transaction_id";
$result_transaction = $conn->query($sql_transaction);

// Check if transaction exists
if ($result_transaction->num_rows > 0) {
    $transaction = $result_transaction->fetch_assoc();
} else {
    // Redirect if transaction not found
    header("Location: ../index.php");
    exit();
}

// Define variables and initialize with the current values
$amount = $transaction['amount'];
$payment = $transaction['payment'];
$date = $transaction['transaction_date'];

// Initialize error variables
$amount_err = $payment_err = $date_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate amount
    if (empty(trim($_POST["amount"]))) {
        $amount_err = "Please enter the amount.";
    } else {
        $amount = trim($_POST["amount"]);
    }

    // Validate payment method
    if (empty(trim($_POST["payment"]))) {
        $payment_err = "Please enter the payment method.";
    } else {
        $payment = trim($_POST["payment"]);
    }

    // Validate date
    if (empty(trim($_POST["date"]))) {
        $date_err = "Please enter the date.";
    } else {
        $date = trim($_POST["date"]);
    }

    // Check input errors before updating the database
    if (empty($amount_err) && empty($payment_err) && empty($date_err)) {
        // Prepare an update statement
        $sql_update = "UPDATE $customer_name SET amount = ?, payment = ?, transaction_date = ? WHERE id = ?";

        if ($stmt = $conn->prepare($sql_update)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("sssi", $param_amount, $param_payment, $param_date, $transaction_id);

            // Set parameters
            $param_amount = $amount;
            $param_payment = $payment;
            $param_date = $date;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to transaction details page after successful update
                header("Location: transaction_details.php?transaction_id=" . $transaction_id . "&customer_name=" . $customer_name);
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }

    // Close connection
    $conn->close();
}
?><!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Transaction | Tirupati Sales</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --light-gray: #f8f9fa;
            --white: #ffffff;
            --border-radius: 10px;
            --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }
        
        .brand-header {
            text-align: center;
            margin: 30px 0;
        }
        
        .brand-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: contain;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 15px;
        }
        
        .brand-title {
            font-size: 24px;
            font-weight: 600;
            color: var(--secondary-color);
        }
        
        .transaction-container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .transaction-card {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 30px;
            margin-bottom: 30px;
            transition: var(--transition);
        }
        
        .transaction-header {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        
        .transaction-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--secondary-color);
            margin-bottom: 5px;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative; /* Added for icon positioning */
        }
        
        .form-label {
            font-weight: 500;
            margin-bottom: 8px;
            display: block;
            color: var(--secondary-color);
        }
        
        .form-control {
            height: 45px;
            border-radius: var(--border-radius);
            border: 1px solid #ddd;
            transition: var(--transition);
            padding-left: 40px; /* Increased padding for icons */
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        /* Icon positioning */
        .input-icon {
            position: absolute;
            left: 15px;
            top: 38px;
            color: #aaa;
            transition: var(--transition);
            z-index: 2;
        }
        
        .form-control:focus + .input-icon {
            color: var(--primary-color);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            padding: 10px 25px;
            border-radius: var(--border-radius);
            font-weight: 500;
            transition: var(--transition);
        }
        
        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        
        @media (max-width: 576px) {
            .transaction-card {
                padding: 20px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-buttons .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="brand-header">
            <img src="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png" alt="Company Logo" class="brand-logo">
            <h1 class="brand-title">Tirupati Sales</h1>
        </div>
        
        <div class="transaction-container">
            <div class="transaction-card">
                <div class="transaction-header">
                    <h2 class="transaction-title">Edit Transaction</h2>
                </div>
                
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?transaction_id=' . $transaction_id . '&customer_name=' . $customer_name; ?>" method="post">
                    <div class="form-group">
                        <label for="amount" class="form-label">Amount</label>
                        <input type="text" name="amount" id="amount" class="form-control <?php echo (!empty($amount_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $amount; ?>">
                        <i class="fas fa-rupee-sign input-icon"></i>
                        <?php if (!empty($amount_err)): ?>
                            <span class="invalid-feedback"><?php echo $amount_err; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="payment" class="form-label">Payment Method</label>
                        <input type="text" name="payment" id="payment" class="form-control <?php echo (!empty($payment_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $payment; ?>">
                        <i class="fas fa-credit-card input-icon"></i>
                        <?php if (!empty($payment_err)): ?>
                            <span class="invalid-feedback"><?php echo $payment_err; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="date" class="form-label">Date</label>
                        <input type="date" name="date" id="date" class="form-control <?php echo (!empty($date_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $date; ?>">
                        <i class="far fa-calendar-alt input-icon"></i>
                        <?php if (!empty($date_err)): ?>
                            <span class="invalid-feedback"><?php echo $date_err; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="../../index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left mr-2"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save mr-2"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>