<?php
session_start();

// Include database connection
include "../../conn.php";

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../../login.php");
    exit();
}

// Check if customer ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../index.php");
    exit();
}

$customer_id = $_GET['id'];

// Fetch customer name from list_of_customers table
$sql = "SELECT * FROM list_of_customers WHERE customer_id = $customer_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $customer = $result->fetch_assoc();
    $customer_name = str_replace(' ', '_', $customer['customer_name']) . '_amount'; // Construct table name
} else {
    // Redirect if customer not found
    header("Location: ../index.php");
    exit();
}
// Initialize variables for form validation
$date = $amount = $payment = ""; // Add $payment variable here
$date_err = $amount_err = $payment_err = ""; // Add $payment_err variable if needed

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate date
    if (empty(trim($_POST["date"]))) {
        $date_err = "Please enter the date.";
    } else {
        $date = trim($_POST["date"]);
    }

    // Validate amount
    if (empty(trim($_POST["amount"]))) {
        $amount_err = "Please enter the amount.";
    } else {
        $amount = trim($_POST["amount"]);
    }

    // Validate payment method
    if (empty(trim($_POST["payment"]))) {
        $payment_err = "Please enter the payment method.";
    } else {
        $payment = trim($_POST["payment"]);
    }

    // Check input errors before inserting into database
    if (empty($date_err) && empty($amount_err) && empty($payment_err)) {
        // Prepare an insert statement
        $sql_insert = "INSERT INTO $customer_name (paid_received, amount, transaction_date, payment) VALUES (0, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql_insert)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("sss", $param_amount, $param_date, $param_payment);

            // Set parameters
            $param_amount = $amount;
            $param_date = $date;
            $param_payment = $payment;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to customer profile page after successful insertion
                header("location: ../customer_profile.php?id=" . $customer_id);
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }

    // Close connection
    $conn->close();
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
<link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png" >
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amount Received</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 50px;
        }

        .container {
            max-width: 600px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #007bff;
            color: #fff;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            padding: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h2>Amount Received</h2>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $customer_id; ?>" method="post">
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" name="date" id="date" class="form-control <?php echo (!empty($date_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $date; ?>">
                        <span class="invalid-feedback"><?php echo $date_err; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="text" name="amount" id="amount" class="form-control <?php echo (!empty($amount_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $amount; ?>">
                        <span class="invalid-feedback"><?php echo $amount_err; ?></span>
                    </div>
                    <div class="form-group">
    <label for="payment">Payment Method</label>
    <input type="text" name="payment" id="payment" class="form-control <?php echo (!empty($payment_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $payment; ?>">
    <span class="invalid-feedback"><?php echo $payment_err; ?></span>
</div>

                    <div class="form-group text-center">
                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                        <a href="../customer_profile.php?id=<?php echo $customer_id; ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
