<?php
include "../conn.php";

// Check if user is logged in
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get customer_id from URL
if (isset($_GET['id'])) {
    $customer_id = (int)$_GET['id']; // Ensure customer_id is an integer

    // Fetch existing customer details
    $sql = "SELECT * FROM list_of_customers WHERE customer_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $customer = $result->fetch_assoc();
        $old_customer_name = $customer['customer_name'];
        $old_customer_name_formatted = str_replace(' ', '_', $old_customer_name);

        // Initialize message variables
        $success_message = '';
        $error_message = '';

        // HTML form for updating customer details
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Get updated data from form submission
            $customer_name = $_POST['customer_name'] ?? $customer['customer_name'];
            $phone = $_POST['phone'] ?? $customer['phone'];
            $new_customer_name_formatted = str_replace(' ', '_', $customer_name);

            // Update query
            $update_sql = "UPDATE list_of_customers SET customer_name = ?, phone = ? WHERE customer_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ssi", $customer_name, $phone, $customer_id);

            if ($update_stmt->execute()) {
                // Fetch all bills tables (exclude the amount table)
                $show_tables_sql = "SHOW TABLES LIKE '{$old_customer_name_formatted}_%'";
                $tables_result = $conn->query($show_tables_sql);

                if ($tables_result) {
                    $errors = [];
                    while ($table = $tables_result->fetch_array()) {
                        $old_table_name = $table[0];

                        // Skip the amount table
                        if ($old_table_name === "{$old_customer_name_formatted}_amount") {
                            continue;
                        }

                        // We expect the table name to be in the format customername_ddmmyyyy
                        // Replace only the customer name part (not the date)
                        $new_table_name = str_replace($old_customer_name_formatted, $new_customer_name_formatted, $old_table_name);

                        $rename_table_sql = "RENAME TABLE `$old_table_name` TO `$new_table_name`;";
                        if (!$conn->query($rename_table_sql)) {
                            $errors[] = "Error renaming table $old_table_name: " . $conn->error;
                        }
                    }

                    // Rename amount table
                    $old_amount_table = "{$old_customer_name_formatted}_amount";
                    $new_amount_table = "{$new_customer_name_formatted}_amount";
                    $rename_amount_sql = "RENAME TABLE `$old_amount_table` TO `$new_amount_table`;";
                    if (!$conn->query($rename_amount_sql)) {
                        $errors[] = "Error renaming amount table: " . $conn->error;
                    }

                    if (empty($errors)) {
                        echo <<<HTML
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Success</title>
                <style>
                    .popup {
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        padding: 20px;
                        background-color: #2ecc71;
                        color: white;
                        font-size: 18px;
                        border-radius: 5px;
                        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                        text-align: center;
                    }
                </style>
                <script>
                    // Redirect after 1 second
                    setTimeout(() => {
                        window.location.href = '../index.php';
                    }, 1000);
                </script>
            </head>
            <body>
                <div class="popup">Customer updated successfully! Redirecting...</div>
            </body>
            </html>
            HTML;
            exit();
                    } else {
                        $error_message = implode("<br>", $errors);
                    }
                } else {
                    $error_message = "Error fetching tables: " . $conn->error;
                }
            } else {
                $error_message = "Error updating customer: " . $conn->error;
            }
        }
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Update Customer</title>
            <style>
                :root {
                    --primary-color: #3498db;
                    --secondary-color: #2980b9;
                    --success-color: #2ecc71;
                    --error-color: #e74c3c;
                    --light-color: #ecf0f1;
                    --dark-color: #2c3e50;
                    --border-radius: 5px;
                    --box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }
                
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                }
                
                body {
                    background-color: #f5f5f5;
                    color: #333;
                    line-height: 1.6;
                    padding: 20px;
                }
                
                .container {
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: white;
                    border-radius: var(--border-radius);
                    box-shadow: var(--box-shadow);
                }
                
                h2 {
                    color: var(--dark-color);
                    margin-bottom: 20px;
                    padding-bottom: 10px;
                    border-bottom: 1px solid #eee;
                }
                
                .form-group {
                    margin-bottom: 20px;
                }
                
                label {
                    display: block;
                    margin-bottom: 5px;
                    font-weight: 600;
                    color: var(--dark-color);
                }
                
                input[type="text"] {
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: var(--border-radius);
                    font-size: 16px;
                    transition: border 0.3s;
                }
                
                input[type="text"]:focus {
                    border-color: var(--primary-color);
                    outline: none;
                    box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
                }
                
                button {
                    background-color: var(--primary-color);
                    color: white;
                    border: none;
                    padding: 12px 20px;
                    border-radius: var(--border-radius);
                    cursor: pointer;
                    font-size: 16px;
                    font-weight: 600;
                    transition: background-color 0.3s;
                }
                
                button:hover {
                    background-color: var(--secondary-color);
                }
                
                .message {
                    padding: 15px;
                    margin-bottom: 20px;
                    border-radius: var(--border-radius);
                }
                
                .success {
                    background-color: #d4edda;
                    color: #155724;
                    border: 1px solid #c3e6cb;
                }
                
                .error {
                    background-color: #f8d7da;
                    color: #721c24;
                    border: 1px solid #f5c6cb;
                }
                
                @media (max-width: 600px) {
                    .container {
                        padding: 15px;
                    }
                    
                    input[type="text"], button {
                        padding: 8px 12px;
                    }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Update Customer</h2>
                
                <?php if ($success_message): ?>
                    <div class="message success">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error_message): ?>
                    <div class="message error">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="customer_name">Customer Name:</label>
                        <input type="text" id="customer_name" name="customer_name" 
                               value="<?php echo htmlspecialchars($customer['customer_name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number:</label>
                        <input type="text" id="phone" name="phone" 
                               value="<?php echo htmlspecialchars($customer['phone']); ?>" required>
                    </div>
                    
                    <button type="submit">Update Customer</button>
                </form>
            </div>
        </body>
        </html>

        <?php
    } else {
        echo '<div class="container"><div class="message error">Customer not found.</div></div>';
    }
} else {
    echo '<div class="container"><div class="message error">Invalid or missing customer ID.</div></div>';
}

// Close connection
$conn->close();
?>