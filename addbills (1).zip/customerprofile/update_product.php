<?php
session_start();

// Include database connection
include "../conn.php";

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../login.php");
    exit();
}

// Check if product name and table name are provided in the URL
if (!isset($_GET['productName']) || !isset($_GET['tableName'])) {
    header("Location: table_details.php");
    exit();
}

$product_name = $_GET['productName'];
$table_name = $_GET['tableName'];
$product_name1 = str_replace(' ', '_', $product_name);



// Fetch product details from the specified table
$sql = "SELECT * FROM $table_name WHERE productName = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $product_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Extract other product details if needed
    $quantity = $row['quantity'];
    $price = $row['price'];
} else {
    echo "Product not found.";
    exit();
}

// Handle form submission for updating product details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve updated product details
    $updated_quantity = $_POST['quantity'];
    $updated_price = $_POST['price'];

    $diff = $quantity - $updated_quantity;

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Update the product details in the database
        $update_sql = "UPDATE $table_name SET quantity = ?, price = ? WHERE productName = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("dds", $updated_quantity, $updated_price, $product_name);
        $update_stmt->execute();

        $product_name2 = str_replace('_', ' ', $product_name1);

        // Update the quantity in the list_of_tables
        $update_list_of_products = "UPDATE list_of_products SET quantity = quantity + ? WHERE product_name = ?";
        $update_diff = $conn->prepare($update_list_of_products);
        $update_diff->bind_param("ds", $diff, $product_name2);
        $update_diff->execute();

        // Commit transaction
        $conn->commit();

        // Redirect back to the table details page with a success message
        echo "<script>alert('Product details updated successfully '); window.location.href='table_details.php?table_name=$table_name';</script>";
        exit();
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        echo "Error updating product details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png" >
    <title>Update Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h2>Update Product: <?php echo htmlspecialchars($product_name); ?></h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo htmlspecialchars($quantity); ?>" required>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($price); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>
</body>

</html>
