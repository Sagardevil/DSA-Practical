<?php
session_start();

// Include database connection
include "../conn.php";

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../login.php");
    exit();
}

// Check if customer ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../index.php");
    exit();
}

$customer_id = $_GET['id'];

// Handle transaction deletion if requested
if (isset($_GET['delete_transaction']) && isset($_GET['transaction_id']) && isset($_GET['table_name'])) {
    $transaction_id = $_GET['transaction_id'];
    $table_name = $_GET['table_name'];
    
    // Delete the transaction
    $delete_sql = "DELETE FROM $table_name WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $transaction_id);
    
    if ($delete_stmt->execute()) {
        $_SESSION['success_message'] = "Transaction deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting transaction: " . $conn->error;
    }
    
    // Redirect back to avoid resubmission
    header("Location: customer_profile.php?id=$customer_id");
    exit();
}

// Fetch customer name from list_of_customers table
$sql = "SELECT * FROM list_of_customers WHERE customer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $customer = $result->fetch_assoc();
    $sss = $customer['customer_name'];
    $customer_name = str_replace(' ', '_', $customer['customer_name']) . '_amount';
    
    // Construct table name
    $formatted_customer_name = str_replace(' ', '_', $customer['customer_name']); // Used for bills section
} else {
    // Redirect if customer not found
    header("Location: ../index.php");
    exit();
}

// Check if the customer's transaction table exists
$check_table_sql = "SHOW TABLES LIKE '$customer_name'";
$table_exists = $conn->query($check_table_sql);

if ($table_exists->num_rows > 0) {
    // Fetch transactions from the dynamically constructed table, sorted by transaction date
    $sql_transactions = "SELECT * FROM $customer_name ORDER BY transaction_date DESC"; // Sort in descending order
    $result_transactions = $conn->query($sql_transactions);
    
    if (!$result_transactions) {
        $transaction_error = "Error fetching transactions: " . $conn->error;
    }
} else {
    $transaction_error = "No transaction records found for this customer.";
    $result_transactions = null;
}

// Fetch tables in the format customer_name_ddmmyyyy
$sql_tables = "SHOW TABLES LIKE '{$formatted_customer_name}_%'";
$result_tables = $conn->query($sql_tables);

if (!$result_tables) {
    $bills_error = "Error fetching bills: " . $conn->error;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Profile - <?php echo htmlspecialchars($customer['customer_name']); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            box-shadow: var(--box-shadow);
            background-color: var(--secondary-color) !important;
        }
        
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .container {
            max-width: 1200px;
            margin-top: 30px;
        }
        
        .customer-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
            padding: 15px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .customer-name {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--secondary-color);
            margin: 0;
        }
        
        .back-btn {
            transition: var(--transition);
        }
        
        .back-btn:hover {
            transform: translateX(-3px);
        }
        
        .nav-tabs {
            margin-bottom: 20px;
            border-bottom: 2px solid #dee2e6;
        }
        
        .nav-link {
            font-weight: 500;
            color: var(--secondary-color);
            border: none;
            padding: 10px 20px;
            transition: var(--transition);
        }
        
        .nav-link.active {
            color: var(--primary-color);
            background-color: transparent;
            border-bottom: 3px solid var(--primary-color);
        }
        
        .nav-link:hover:not(.active) {
            color: var(--primary-color);
        }
        
        .content-container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            min-height: 400px;
            margin-bottom: 100px;
        }
        
        .transaction-card {
            border-left: 4px solid var(--primary-color);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 15px;
            background-color: white;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            cursor: pointer;
            position: relative;
        }
        
        .transaction-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }
        
        .transaction-type {
            font-weight: 600;
            color: var(--secondary-color);
            display: flex;
            align-items: center;
        }
        
        .transaction-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .transaction-amount {
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .transaction-date {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .badge-pill {
            padding: 5px 10px;
            font-size: 0.8rem;
        }
        
        .badge-success {
            background-color: var(--success-color);
        }
        
        .badge-danger {
            background-color: var(--danger-color);
        }
        
        .error-message {
            background-color: #f8d7da;
            color: var(--danger-color);
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
        }
        
        .info-message {
            background-color: #d1ecf1;
            color: #0c5460;
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
        }
        
        .floating-buttons-container {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            padding: 15px 0;
            box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .action-btn {
            border-radius: 50px;
            padding: 12px 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: var(--transition);
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .action-btn i {
            margin-right: 8px;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        
        .btn-success {
            background-color: var(--success-color);
        }
        
        .btn-danger {
            background-color: var(--danger-color);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
        }
        
        .scrollable-container {
            max-height: 500px;
            overflow-y: auto;
            padding-right: 10px;
        }
        
        /* Custom scrollbar */
        .scrollable-container::-webkit-scrollbar {
            width: 8px;
        }
        
        .scrollable-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        .scrollable-container::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 10px;
        }
        
        .scrollable-container::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* Update and Delete Links */
        .customer-actions {
            display: flex;
            gap: 15px;
        }
        
        .customer-action-link {
            padding: 8px 12px;
            border-radius: 5px;
            font-weight: 500;
            transition: var(--transition);
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .update-link {
            background-color: #ffc107;
            color: #212529;
        }
        
        .update-link:hover {
            background-color: #e0a800;
            color: #212529;
            text-decoration: none;
        }
        
        .delete-link {
            background-color: var(--danger-color);
            color: white;
        }
        
        .delete-link:hover {
            background-color: #c82333;
            color: white;
            text-decoration: none;
        }
        
        /* Delete button in transaction */
        .delete-transaction-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: transparent;
            border: none;
            color: #dc3545;
            cursor: pointer;
            font-size: 1rem;
            opacity: 0;
            transition: var(--transition);
        }
        
        .transaction-card:hover .delete-transaction-btn {
            opacity: 1;
        }
        
        .delete-transaction-btn:hover {
            color: #bd2130;
        }
        
        /* Confirmation modal */
        .confirmation-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .confirmation-dialog {
            background-color: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            max-width: 500px;
            width: 90%;
        }
        
        .confirmation-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .customer-name {
                font-size: 1.3rem;
            }
            
            .action-btn {
                padding: 10px 15px;
                font-size: 0.9rem;
            }
            
            .scrollable-container {
                max-height: 400px;
            }
            
            .customer-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .customer-actions {
                justify-content: center;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-store mr-2"></i>Tirupati Sales
            </a>
        </div>
    </nav>

    <div class="container">
        <!-- Display success/error messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success_message']; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error_message']; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <div class="customer-header">
            <a href="../index.php" class="btn btn-outline-secondary back-btn">
                <i class="fas fa-arrow-left mr-2"></i>Back
            </a>
            <h1 class="customer-name">
                <i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($customer['customer_name']); ?>
            </h1>
            <div class="customer-actions">
                <a href="update_customer.php?id=<?php echo $customer['customer_id']; ?>" class="customer-action-link update-link">
                    <i class="fas fa-edit mr-2"></i>Update Customer
                </a>
                <a href="delete_customer.php?id=<?php echo $customer['customer_id']; ?>" class="customer-action-link delete-link">
                    <i class="fas fa-trash-alt mr-2"></i>Delete Customer
                </a>
            </div>
        </div>

        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="transactions-tab" data-toggle="tab" data-target="#transactions" type="button" role="tab" aria-controls="transactions" aria-selected="true">
                    <i class="fas fa-exchange-alt mr-2"></i>Transactions
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="bills-tab" data-toggle="tab" data-target="#bills" type="button" role="tab" aria-controls="bills" aria-selected="false">
                    <i class="fas fa-file-invoice mr-2"></i>Bills
                </button>
            </li>
        </ul>

        <div class="tab-content content-container">
            <div class="tab-pane fade show active scrollable-container" id="transactions" role="tabpanel" aria-labelledby="transactions-tab">
                <?php if (isset($transaction_error)): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle mr-2"></i><?php echo $transaction_error; ?>
                    </div>
                <?php elseif ($result_transactions && $result_transactions->num_rows > 0): ?>
                    <?php while ($row = $result_transactions->fetch_assoc()): ?>
                        <div class="transaction-card">
                            <button class="delete-transaction-btn" 
                                    onclick="confirmDeleteTransaction(<?php echo $row['id']; ?>, '<?php echo $customer_name; ?>', <?php echo $customer_id; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                            <div onclick="showTransactionDetails(<?php echo $row['id']; ?>, '<?php echo $customer_name; ?>')">
                                <div class="transaction-details">
                                    <div class="transaction-type">
                                        <?php if ($row['paid_received']): ?>
                                            <span class="badge badge-danger badge-pill mr-2"><i class="fas fa-shopping-basket"></i></span>
                                            Products Purchased
                                        <?php else: ?>
                                            <span class="badge badge-success badge-pill mr-2"><i class="fas fa-rupee-sign"></i></span>
                                            Amount Received
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-right">
                                        <div class="transaction-amount">
                                            ₹<?php echo $row['amount']; ?>
                                        </div>
                                        <div class="transaction-date">
                                            <i class="far fa-calendar-alt mr-1"></i><?php echo $row['transaction_date']; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="info-message">
                        <i class="fas fa-info-circle mr-2"></i>No transactions found for this customer.
                    </div>
                <?php endif; ?>
            </div>

            <div class="tab-pane fade scrollable-container" id="bills" role="tabpanel" aria-labelledby="bills-tab">
                <?php if (isset($bills_error)): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle mr-2"></i><?php echo $bills_error; ?>
                    </div>
                <?php elseif ($result_tables && $result_tables->num_rows > 0): ?>
                    <?php while ($row = $result_tables->fetch_assoc()): ?>
                        <?php
                        $table_name = $row[array_key_first($row)];
                        $display_name = str_replace('_', ' ', $table_name);
                        $date_part = substr($display_name, -8);
                        $name_part = substr($display_name, 0, strlen($display_name) - 8);
                        ?>
                        <div class="transaction-card" onclick="showTableDetails('<?php echo $table_name; ?>', <?php echo $customer_id; ?>)">
                            <div class="transaction-details">
                                <div class="transaction-type">
                                    <span class="badge badge-primary badge-pill mr-2"><i class="fas fa-file-invoice"></i></span>
                                    <?php echo $name_part; ?>
                                </div>
                                <div class="transaction-date">
                                    <i class="far fa-calendar-alt mr-1"></i><?php echo $date_part; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="info-message">
                        <i class="fas fa-info-circle mr-2"></i>No bills found for this customer.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div class="confirmation-modal" id="confirmationModal">
        <div class="confirmation-dialog">
            <h5>Confirm Deletion</h5>
            <p>Are you sure you want to delete this transaction? This action cannot be undone.</p>
            <div class="confirmation-buttons">
                <button class="btn btn-secondary" onclick="cancelDelete()">Cancel</button>
                <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
            </div>
        </div>
    </div>

    <div class="floating-buttons-container">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-2 mb-md-0">
                    <button class="action-btn btn-danger w-100" id="Product" onclick="redirectToProducts()">
                        <i class="fas fa-shopping-basket"></i> Product Purchased
                    </button>
                </div>
                <div class="col-md-4 mb-2 mb-md-0">
                    <button class="action-btn btn-success w-100" id="Amount" onclick="redirectToAmount()">
                        <i class="fas fa-rupee-sign"></i> Amount Received
                    </button>
                </div>
                <div class="col-md-4">
                    <button class="action-btn btn-primary w-100" id="addbillbutton" onclick="addBill()" style="display:none;">
                        <i class="fas fa-plus-circle"></i> Add Bill
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Variables to store transaction deletion data
        let transactionToDelete = null;
        let tableNameToDelete = null;
        let customerIdToDelete = null;
        
        // Activate Bootstrap tabs
        $('#myTab a').on('click', function (e) {
            e.preventDefault();
            $(this).tab('show');
            
            // Show/hide appropriate action buttons based on active tab
            if ($(this).attr('id') === 'bills-tab') {
                document.getElementById("addbillbutton").style.display = "block";
                document.getElementById("Amount").style.display = "none";
                document.getElementById("Product").style.display = "none";
            } else {
                document.getElementById("addbillbutton").style.display = "none";
                document.getElementById("Amount").style.display = "block";
                document.getElementById("Product").style.display = "block";
            }
        });

        // Function to redirect to add a bill page
        function addBill() {
            window.location.href = '../addbills/add_bills.php?id=<?php echo $customer_id; ?>';
        }

        // JavaScript function to redirect to the "Products Purchased" page
        function redirectToProducts() {
            window.location.href = 'transaction/products_purchased.php?id=<?php echo $customer_id; ?>';
        }

        // JavaScript function to redirect to the "Amount Received" page
        function redirectToAmount() {
            window.location.href = 'transaction/amount_received.php?id=<?php echo $customer_id; ?>';
        }

        // JavaScript function to show transaction details
        function showTransactionDetails(transactionId, customerName) {
            window.location.href = 'transaction/transaction_details.php?transaction_id=' + transactionId + "&customer_name=" + customerName;
        }

        // JavaScript function to show table details
        function showTableDetails(tableName, customerId) {
            window.location.href = 'table_details.php?table_name=' + tableName + '&id=' + customerId;
        }
        
        // Function to confirm transaction deletion
        function confirmDeleteTransaction(transactionId, tableName, customerId) {
            // Stop event propagation to prevent card click
            event.stopPropagation();
            
            // Store the data for deletion
            transactionToDelete = transactionId;
            tableNameToDelete = tableName;
            customerIdToDelete = customerId;
            
            // Show the confirmation modal
            document.getElementById('confirmationModal').style.display = 'flex';
            
            // Set up the confirm button
            document.getElementById('confirmDeleteBtn').onclick = function() {
                deleteTransaction();
            };
        }
        
        // Function to cancel deletion
        function cancelDelete() {
            // Hide the modal
            document.getElementById('confirmationModal').style.display = 'none';
            
            // Reset the variables
            transactionToDelete = null;
            tableNameToDelete = null;
            customerIdToDelete = null;
        }
        
        // Function to perform the deletion
        function deleteTransaction() {
            if (transactionToDelete && tableNameToDelete && customerIdToDelete) {
                // Redirect to delete the transaction
                window.location.href = `customer_profile.php?id=${customerIdToDelete}&delete_transaction=1&transaction_id=${transactionToDelete}&table_name=${tableNameToDelete}`;
            }
        }
    </script>
</body>

</html>