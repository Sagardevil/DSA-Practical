<?php
session_start();

// Include database connection
include "../conn.php";

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo 'Unauthorized access';
    exit();
}

// Check if customer ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo 'Invalid request';
    exit();
}

$customer_id = $_GET['id'];

// Fetch customer name from list_of_customers table
$sql = "SELECT * FROM list_of_customers WHERE customer_id = $customer_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $customer = $result->fetch_assoc();
    $customer_name = str_replace(' ', '_', $customer['customer_name']) . '_amount'; // Construct table name
} else {
    echo 'Customer not found';
    exit();
}

// Filter transactions based on selected option
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$sql_transactions = '';

switch ($filter) {
    case 'received':
        $sql_transactions = "SELECT * FROM $customer_name WHERE paid_received = 0";
        break;
    case 'purchased':
        $sql_transactions = "SELECT * FROM $customer_name WHERE paid_received = 1";
        break;
    default:
        $sql_transactions = "SELECT * FROM $customer_name";
        break;
}

$result_transactions = $conn->query($sql_transactions);

if ($result_transactions->num_rows > 0) {
    while ($row = $result_transactions->fetch_assoc()) {
        // Output transaction details
        echo '<div class="transaction">';
        echo '<div class="transaction-details">';
        echo '<span class="transaction-type">' . ($row['paid_received'] ? 'Products Purchased' : 'Amount Received') . '</span>';
        echo '<span class="amount-date">';
        echo 'Amount: ' . $row['amount'];
        echo ' | Date: ' . $row['transaction_date'];
        echo '</span>';
        echo '</div>'; // transaction-details
        echo '</div>'; // transaction
    }
} else {
    echo 'No transactions found.';
}

$conn->close();
?>
