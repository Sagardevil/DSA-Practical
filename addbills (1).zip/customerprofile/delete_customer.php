<?php
include "../conn.php";

// Check if user is logged in
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get customer_id from URL
if (isset($_GET['id'])) {
    $customer_id = (int)$_GET['id']; // Ensure customer_id is an integer

    // Fetch existing customer details
    $sql = "SELECT * FROM list_of_customers WHERE customer_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $customer = $result->fetch_assoc();
        $customer_name = $customer['customer_name'];
        $customer_phone = $customer['phone'];
        $customer_name_formatted = str_replace(' ', '_', $customer_name);

        // Fetch all bills and amount
        $bills = [];
        $show_tables_sql = "SHOW TABLES LIKE '{$customer_name_formatted}_%'";
        $tables_result = $conn->query($show_tables_sql);
        if ($tables_result) {
            while ($table = $tables_result->fetch_array()) {
                $table_name = $table[0];
                if ($table_name !== "{$customer_name_formatted}_amount") {
                    $bills[] = $table_name;
                }
            }
        }

        $amount_table = "{$customer_name_formatted}_amount";
        $amounts = [];
        if ($conn->query("SHOW TABLES LIKE '$amount_table'")->num_rows > 0) {
            $amount_result = $conn->query("SELECT * FROM `$amount_table`");
            if ($amount_result) {
                while ($row = $amount_result->fetch_assoc()) {
                    $amounts[] = $row;
                }
            }
        }

        // Handle delete confirmation
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Delete bills tables
            foreach ($bills as $bill_table) {
                $conn->query("DROP TABLE `$bill_table`");
            }

            // Delete amount table
            $conn->query("DROP TABLE `$amount_table`");

            // Delete customer from list_of_customers
            $delete_sql = "DELETE FROM list_of_customers WHERE customer_id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $customer_id);
            if ($delete_stmt->execute()) {
                echo "<script>
                    document.getElementById('success-animation').style.display = 'flex';
                    setTimeout(() => { window.location.href = '../index.php'; }, 2000);
                </script>";
            } else {
                echo "<div class='message error'><i class='fas fa-exclamation-triangle'></i> Error deleting customer: " . $conn->error . "</div>";
            }
        }

        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Delete Customer</title>
            <!-- Font Awesome for icons -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <!-- Google Fonts -->
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
            <!-- Animate.css for animations -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
            <style>
                :root {
                    --primary-color: #3498db;
                    --primary-dark: #2980b9;
                    --secondary-color: #2c3e50;
                    --success-color: #2ecc71;
                    --warning-color: #f39c12;
                    --danger-color: #e74c3c;
                    --danger-dark: #c0392b;
                    --light-color: #ecf0f1;
                    --dark-color: #2c3e50;
                    --border-radius: 8px;
                    --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                    --transition: all 0.3s ease;
                }
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    font-family: 'Poppins', sans-serif;
                }
                body {
                    background-color: #f8f9fa;
                    color: #333;
                    line-height: 1.6;
                    padding: 0;
                    margin: 0;
                }
                .logo-container {
                    text-align: center;
                    padding: 20px 0;
                    background: linear-gradient(135deg, var(--dark-color), var(--primary-dark));
                    color: white;
                    margin-bottom: 30px;
                    box-shadow: var(--box-shadow);
                }
                .logo {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 10px;
                    font-size: 28px;
                    font-weight: 700;
                }
                .logo i {
                    font-size: 32px;
                }
                .container {
                    max-width: 900px;
                    margin: 0 auto 50px;
                    padding: 30px;
                    background-color: white;
                    border-radius: var(--border-radius);
                    box-shadow: var(--box-shadow);
                    animation: fadeIn 0.5s ease;
                }
                h2 {
                    color: var(--dark-color);
                    margin-bottom: 25px;
                    position: relative;
                    padding-bottom: 10px;
                    border-bottom: 2px solid var(--primary-color);
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                h3 {
                    color: var(--dark-color);
                    margin: 25px 0 15px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .customer-info {
                    background-color: #f8f9fa;
                    padding: 25px;
                    border-radius: var(--border-radius);
                    margin-bottom: 20px;
                    border-left: 4px solid var(--primary-color);
                    transition: var(--transition);
                }
                .customer-info:hover {
                    transform: translateY(-5px);
                    box-shadow: var(--box-shadow);
                }
                .info-item {
                    display: flex;
                    align-items: center;
                    margin-bottom: 15px;
                    font-size: 18px;
                }
                .info-item i {
                    margin-right: 15px;
                    color: var(--primary-color);
                    width: 25px;
                    text-align: center;
                    font-size: 22px;
                }
                .info-item strong {
                    margin-right: 10px;
                    font-weight: 600;
                }
                .info-value {
                    font-size: 20px;
                    font-weight: 500;
                }
                .message {
                    padding: 15px;
                    margin-bottom: 20px;
                    border-radius: var(--border-radius);
                    display: flex;
                    align-items: center;
                    animation: fadeIn 0.5s ease;
                }
                .message i {
                    margin-right: 10px;
                    font-size: 18px;
                }
                .error {
                    background-color: #f8d7da;
                    color: #721c24;
                    border-left: 4px solid var(--danger-color);
                }
                .warning {
                    background-color: #fff3cd;
                    color: #856404;
                    border-left: 4px solid var(--warning-color);
                    margin: 20px 0;
                    font-weight: 500;
                }
                .table-container {
                    overflow-x: auto;
                    margin-bottom: 25px;
                    border-radius: var(--border-radius);
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                table, th, td {
                    border: 1px solid #eee;
                }
                th, td {
                    padding: 12px 15px;
                    text-align: left;
                }
                th {
                    background: linear-gradient(135deg, var(--primary-color), var(--dark-color));
                    color: white;
                    font-weight: 500;
                }
                tbody tr {
                    transition: var(--transition);
                }
                tbody tr:nth-child(even) {
                    background-color: #f8f9fa;
                }
                tbody tr:hover {
                    background-color: #f1f1f1;
                }
                .btn-container {
                    display: flex;
                    gap: 15px;
                    margin-top: 30px;
                }
                .btn {
                    padding: 12px 24px;
                    border-radius: var(--border-radius);
                    border: none;
                    font-weight: 500;
                    cursor: pointer;
                    transition: var(--transition);
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    font-size: 16px;
                }
                .btn-delete {
                    background-color: var(--danger-color);
                    color: white;
                }
                .btn-delete:hover {
                    background-color: var(--danger-dark);
                    transform: translateY(-2px);
                    box-shadow: 0 5px 10px rgba(231, 76, 60, 0.3);
                }
                .btn-cancel {
                    background-color: #6c757d;
                    color: white;
                }
                .btn-cancel:hover {
                    background-color: #5a6268;
                    transform: translateY(-2px);
                    box-shadow: 0 5px 10px rgba(108, 117, 125, 0.3);
                }
                .empty-state {
                    text-align: center;
                    padding: 20px;
                    color: #6c757d;
                    font-style: italic;
                }
                #success-animation {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.8);
                    display: none;
                    justify-content: center;
                    align-items: center;
                    flex-direction: column;
                    z-index: 1000;
                }
                .success-content {
                    text-align: center;
                    color: white;
                }
                .checkmark {
                    width: 80px;
                    height: 80px;
                    border-radius: 50%;
                    display: block;
                    stroke-width: 2;
                    stroke: var(--success-color);
                    stroke-miterlimit: 10;
                    box-shadow: 0 0 20px var(--success-color);
                    animation: fillCheckmark 0.4s ease-in-out 0.4s forwards, scale 0.3s ease-in-out 0.9s both;
                    margin: 0 auto 20px;
                }
                .checkmark__circle {
                    stroke-dasharray: 166;
                    stroke-dashoffset: 166;
                    stroke-width: 2;
                    stroke-miterlimit: 10;
                    fill: none;
                    animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
                }
                .checkmark__check {
                    transform-origin: 50% 50%;
                    stroke-dasharray: 48;
                    stroke-dashoffset: 48;
                    animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
                }
                @keyframes stroke {
                    100% {
                        stroke-dashoffset: 0;
                    }
                }
                @keyframes scale {
                    0%, 100% {
                        transform: none;
                    }
                    50% {
                        transform: scale3d(1.1, 1.1, 1);
                    }
                }
                @keyframes fillCheckmark {
                    100% {
                        box-shadow: inset 0 0 0 80px var(--success-color);
                    }
                }
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                .back-to-home {
                    position: fixed;
                    bottom: 30px;
                    right: 30px;
                    background-color: var(--dark-color);
                    color: white;
                    width: 50px;
                    height: 50px;
                    border-radius: 50%;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    box-shadow: var(--box-shadow);
                    transition: var(--transition);
                    text-decoration: none;
                }
                .back-to-home:hover {
                    background-color: var(--primary-color);
                    transform: translateY(-5px);
                }
                .customer-header {
                    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
                    color: white;
                    padding: 15px;
                    border-radius: var(--border-radius) var(--border-radius) 0 0;
                    font-size: 22px;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .customer-header i {
                    font-size: 26px;
                }
                .customer-details {
                    border: 1px solid #ddd;
                    border-radius: var(--border-radius);
                    overflow: hidden;
                    box-shadow: var(--box-shadow);
                    margin-bottom: 30px;
                    animation: fadeIn 0.5s ease;
                }
                .customer-body {
                    padding: 25px;
                    background-color: white;
                }
                @media (max-width: 768px) {
                    .container {
                        padding: 20px;
                        margin: 10px;
                    }
                    .btn-container {
                        flex-direction: column;
                    }
                    .btn {
                        width: 100%;
                    }
                    .back-to-home {
                        bottom: 20px;
                        right: 20px;
                    }
                }
            </style>
        </head>
        <body>
            <div class="logo-container">
                <div class="logo animate__animated animate__bounceIn">
                    <i class="fas fa-users-cog"></i> Customer Management System
                </div>
            </div>

            <div class="container">
                <h2 class="animate__animated animate__fadeInDown">
                    <i class="fas fa-user-minus"></i> Delete Customer
                </h2>

                <div class="warning animate__animated animate__fadeIn animate__delay-1s">
                    <i class="fas fa-exclamation-triangle"></i> Warning: This action cannot be undone. All customer data will be permanently deleted.
                </div>

                <div class="customer-details animate__animated animate__fadeIn">
                    <div class="customer-header">
                        <i class="fas fa-id-card"></i> Customer Details
                    </div>
                    <div class="customer-body">
                        <div class="info-item">
                            <i class="fas fa-user"></i>
                            <strong>Name:</strong> 
                            <span class="info-value"><?php echo htmlspecialchars($customer_name); ?></span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-phone"></i>
                            <strong>Phone:</strong>
                            <span class="info-value"><?php echo htmlspecialchars($customer_phone); ?></span>
                        </div>
                    </div>
                </div>

                <h3 class="animate__animated animate__fadeIn animate__delay-1s">
                    <i class="fas fa-file-invoice"></i> Associated Bills
                </h3>
                <?php if (!empty($bills)): ?>
                    <div class="table-container animate__animated animate__fadeIn animate__delay-1s">
                        <table>
                            <thead>
                                <tr>
                                    <th><i class="fas fa-list-ul"></i> Bill Table Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bills as $bill): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($bill); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state animate__animated animate__fadeIn animate__delay-1s">
                        <i class="fas fa-folder-open"></i> No bills found for this customer.
                    </div>
                <?php endif; ?>

                <h3 class="animate__animated animate__fadeIn animate__delay-2s">
                    <i class="fas fa-wallet"></i> Amount Details
                </h3>
                <?php if (!empty($amounts)): ?>
                    <div class="table-container animate__animated animate__fadeIn animate__delay-2s">
                        <table>
                            <thead>
                                <tr>
                                    <th><i class="fas fa-hashtag"></i> ID</th>
                                    <th><i class="fas fa-dollar-sign"></i> Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($amounts as $amount): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($amount['id']); ?></td>
                                        <td><?php echo htmlspecialchars($amount['amount']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state animate__animated animate__fadeIn animate__delay-2s">
                        <i class="fas fa-coins"></i> No amount records found for this customer.
                    </div>
                <?php endif; ?>

                <form method="POST" class="animate__animated animate__fadeIn animate__delay-3s">
                    <div class="btn-container">
                        <button type="submit" class="btn btn-delete">
                            <i class="fas fa-trash-alt"></i> Confirm Delete
                        </button>
                        <a href="../index.php" class="btn btn-cancel">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>

            <a href="../index.php" class="back-to-home animate__animated animate__fadeInRight animate__delay-3s">
                <i class="fas fa-home"></i>
            </a>

            <!-- Success Animation Overlay -->
            <div id="success-animation">
                <div class="success-content animate__animated animate__zoomIn">
                    <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                        <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
                        <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                    </svg>
                    <h2>Customer Deleted Successfully!</h2>
                    <p>Redirecting to homepage...</p>
                </div>
            </div>

        </body>
        </html>

        <?php
    } else {
        echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Error</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
            <style>
                :root {
                    --primary-color: #3498db;
                    --danger-color: #e74c3c;
                    --dark-color: #2c3e50;
                    --border-radius: 8px;
                    --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                }
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    font-family: "Poppins", sans-serif;
                }
                body {
                    background-color: #f8f9fa;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    padding: 20px;
                }
                .container {
                    max-width: 600px;
                    padding: 30px;
                    background-color: white;
                    border-radius: var(--border-radius);
                    box-shadow: var(--box-shadow);
                    text-align: center;
                    animation: fadeIn 0.5s ease;
                }
                .error-icon {
                    font-size: 60px;
                    color: var(--danger-color);
                    margin-bottom: 20px;
                }
                h2 {
                    color: var(--dark-color);
                    margin-bottom: 20px;
                }
                .message {
                    background-color: #f8d7da;
                    color: #721c24;
                    padding: 15px;
                    border-radius: var(--border-radius);
                    margin-bottom: 25px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .message i {
                    margin-right: 10px;
                }
                .btn {
                    display: inline-block;
                    padding: 12px 24px;
                    background-color: var(--dark-color);
                    color: white;
                    text-decoration: none;
                    border-radius: var(--border-radius);
                    transition: all 0.3s ease;
                }
                .btn:hover {
                    background-color: #1a252f;
                    transform: translateY(-2px);
                }
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            </style>
        </head>
        <body>
            <div class="container animate__animated animate__fadeIn">
                <i class="fas fa-exclamation-circle error-icon animate__animated animate__pulse animate__infinite"></i>
                <h2>Customer Not Found</h2>
                <div class="message">
                    <i class="fas fa-info-circle"></i> The requested customer could not be found in our database.
                </div>
                <a href="../index.php" class="btn">
                    <i class="fas fa-home"></i> Back to Home
                </a>
            </div>
        </body>
        </html>';
    }
} else {
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
        <style>
            :root {
                --primary-color: #3498db;
                --danger-color: #e74c3c;
                --dark-color: #2c3e50;
                --border-radius: 8px;
                --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            }
            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
                font-family: "Poppins", sans-serif;
            }
            body {
                background-color: #f8f9fa;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 600px;
                padding: 30px;
                background-color: white;
                border-radius: var(--border-radius);
                box-shadow: var(--box-shadow);
                text-align: center;
                animation: fadeIn 0.5s ease;
            }
            .error-icon {
                font-size: 60px;
                color: var(--danger-color);
                margin-bottom: 20px;
            }
            h2 {
                color: var(--dark-color);
                margin-bottom: 20px;
            }
            .message {
                background-color: #f8d7da;
                color: #721c24;
                padding: 15px;
                border-radius: var(--border-radius);
                margin-bottom: 25px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .message i {
                margin-right: 10px;
            }
            .btn {
                display: inline-block;
                padding: 12px 24px;
                background-color: var(--dark-color);
                color: white;
                text-decoration: none;
                border-radius: var(--border-radius);
                transition: all 0.3s ease;
            }
            .btn:hover {
                background-color: #1a252f;
                transform: translateY(-2px);
            }
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        </style>
    </head>
    <body>
        <div class="container animate__animated animate__fadeIn">
            <i class="fas fa-exclamation-triangle error-icon animate__animated animate__pulse animate__infinite"></i>
            <h2>Invalid Request</h2>
            <div class="message">
                <i class="fas fa-info-circle"></i> Invalid or missing customer ID.
            </div>
            <a href="../index.php" class="btn">
                <i class="fas fa-home"></i> Back to Home
            </a>
        </div>
    </body>
    </html>';
}

// Close connection
$conn->close();
?>