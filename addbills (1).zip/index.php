<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('auth.php');
check_login();

// Database connection
include 'conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error . " - Please check your database credentials in conn.php");
}

// Fetch list of customers
$sql = "SELECT * FROM list_of_customers";
$result = $conn->query($sql);
if (!$result) {
    echo "Query error: " . $conn->error;
}

$customers = array();
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $customers[] = $row;
    }
}

// Search functionality with SQL injection protection
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $stmt = $conn->prepare("SELECT * FROM list_of_customers WHERE customer_name LIKE ?");
    if ($stmt) {
        $searchParam = "%$search%";
        $stmt->bind_param("s", $searchParam);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $customers = array();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $customers[] = $row;
            }
        }
    } else {
        echo "Prepared statement error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Tirupati Sales & Rudra Trading Company</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">

    <style>
        :root {
            --primary-color: #3579f6;
            --secondary-color: #28a745;
            --dark-color: #343a40;
            --light-color: #f8f9fa;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --border-radius: 10px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }

        /* Navbar Styling */
        .navbar {
            background: linear-gradient(135deg, var(--dark-color), #1a1e21);
            box-shadow: var(--box-shadow);
            padding: 15px 0;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            letter-spacing: 0.5px;
        }

        .navbar-dark .navbar-nav .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 500;
            transition: var(--transition);
            border-radius: 5px;
            padding: 8px 15px;
        }

        .navbar-dark .navbar-nav .nav-link:hover {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }

        /* Container Styling */
        .container {
            margin-top: 30px;
        }

        /* Search Box */
        .search-container {
            margin-bottom: 30px;
            position: relative;
        }

        .search-box {
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            background-color: white;
            padding: 20px;
        }

        .search-box .form-control {
            border-radius: 30px 0 0 30px;
            border: 1px solid #ddd;
            padding: 12px 20px;
            font-size: 1rem;
            box-shadow: none;
        }

        .search-box .btn-primary {
            border-radius: 0 30px 30px 0;
            padding: 12px 25px;
            background: var(--primary-color);
            border: none;
            transition: var(--transition);
        }

        .search-box .btn-primary:hover {
            background: #2760c5;
        }

        /* Tab Buttons Styling */
        .tab-buttons {
            display: flex;
            margin-bottom: 20px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }

        .tab-button {
            flex: 1;
            text-align: center;
            padding: 15px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            transition: var(--transition);
            border: none;
            background-color: white;
            color: #555;
        }

        .tab-button.active-customer {
            background-color: var(--primary-color);
            color: white;
        }

        .tab-button.active-stock {
            background-color: var(--secondary-color);
            color: white;
        }

        .tab-button:hover:not(.active-customer):not(.active-stock) {
            background-color: #f5f5f5;
        }

        .tab-button i {
            margin-right: 10px;
        }

        /* Main Content Area */
        .main-content {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            height: 550px;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: #ccc #f5f5f5;
        }

        .main-content::-webkit-scrollbar {
            width: 6px;
        }

        .main-content::-webkit-scrollbar-track {
            background: #f5f5f5;
        }

        .main-content::-webkit-scrollbar-thumb {
            background-color: #ccc;
            border-radius: 10px;
        }

        /* Customer List Styling */
        .list-group-item {
            border-left: none;
            border-right: none;
            border-radius: 0 !important;
            padding: 15px 20px;
            margin: 0;
            transition: var(--transition);
            border-bottom: 1px solid #eee;
        }

        .list-group-item:first-child {
            border-top: none;
        }

        .list-group-item-action {
            cursor: pointer;
        }

        .list-group-item-action:hover {
            background-color: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .list-group-item .badge {
            float: right;
            padding: 8px 12px;
            font-size: 0.85rem;
            font-weight: 600;
            border-radius: 30px;
        }

        .badge-primary {
            background-color: var(--primary-color);
        }

        .badge-danger {
            background-color: var(--danger-color);
        }

        .badge-success {
            background-color: var(--secondary-color);
        }

        /* Action Buttons Container */
        .action-buttons {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background: #f8f9fa;
            border-top: 1px solid #eee;
            padding: 15px 0;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }

        .action-button {
            padding: 10px 20px;
            border-radius: 50px;
            margin: 5px 10px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            transition: var(--transition);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            min-width: 150px;
            justify-content: center;
        }

        .action-button i {
            margin-right: 8px;
        }

        .btn-add-customer {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-add-customer:hover {
            background-color: #2760c5;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .btn-add-bills {
            background-color: var(--secondary-color);
            color: white;
        }

        .btn-add-bills:hover {
            background-color: #218838;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .btn-view-credit {
            background-color: #17a2b8;
            color: white;
        }

        .btn-view-credit:hover {
            background-color: #138496;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .btn-view-revenue {
            background-color: #6f42c1;
            color: white;
        }

        .btn-view-revenue:hover {
            background-color: #5e35b1;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .btn-add-stock, .btn-display-stock, .btn-add-product {
            background-color: var(--secondary-color);
            color: white;
        }

        .btn-add-stock:hover, .btn-display-stock:hover, .btn-add-product:hover {
            background-color: #218838;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #888;
        }

        .empty-state i {
            font-size: 5rem;
            margin-bottom: 20px;
            color: #ddd;
        }

        /* Responsive Adjustments */
        @media (max-width: 991px) {
            .main-content {
                height: 500px;
            }
        }

        @media (max-width: 767px) {
            .action-buttons {
                flex-direction: row;
                padding: 10px 0;
            }
            
            .action-button {
                font-size: 0.85rem;
                padding: 8px 16px;
                margin: 5px;
                min-width: 120px;
            }
            
            .main-content {
                height: calc(100vh - 320px);
            }
            
            .navbar-brand {
                font-size: 1.2rem;
            }
            
            .search-box .form-control,
            .search-box .btn-primary {
                padding: 10px 15px;
            }
            
            .tab-button {
                padding: 12px 5px;
                font-size: 0.9rem;
            }
            
            .tab-button i {
                margin-right: 5px;
            }
        }

        @media (max-width: 575px) {
            .action-button {
                font-size: 0.75rem;
                padding: 8px 12px;
                min-width: 110px;
                margin: 3px;
            }
            
            .action-buttons {
                padding: 8px 0;
            }
            
            .main-content {
                height: calc(100vh - 300px);
            }
            
            .list-group-item {
                padding: 12px 15px;
            }
            
            .list-group-item .badge {
                padding: 5px 8px;
                font-size: 0.75rem;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-store mr-2"></i>Tirupati Sales & Rudra Trading
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt mr-1"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="container">
        <!-- Search Box -->
        <div class="row">
            <div class="col-12">
                <div class="search-container">
                    <div class="search-box">
                        <form class="form-inline">
                            <div class="input-group w-100">
                                <input type="text" class="form-control" name="search" placeholder="Search Customer..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search mr-1"></i> Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tab Buttons -->
        <div class="row">
            <div class="col-12">
                <div class="tab-buttons">
                    <button class="tab-button active-customer" id="Product">
                        <i class="fas fa-users"></i> Customers
                    </button>
                    <button class="tab-button" id="Amount">
                        <i class="fas fa-boxes"></i> Stock
                    </button>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="row">
            <div class="col-12">
                <div class="main-content">
                    <!-- Customers View -->
                    <div id="customer">
                        <?php if (!empty($customers)) : ?>
                            <ul class="list-group">
                            <?php
                           
                            foreach ($customers as $customer) : 
                                // Generate table name from customer name
                                $table_name = str_replace(' ', '_', $customer['customer_name']) . '_amount';
                                
                                // Check if table exists before querying
                                $check_table = $conn->query("SHOW TABLES LIKE '$table_name'");
                                $table_exists = $check_table && $check_table->num_rows > 0;
                                
                                $remaining_amount = 0;
$totalamount = 0; // Initialize total amount

if ($table_exists) {
    // Query to calculate remaining amount
    $remaining_amount_sql = "
        SELECT COALESCE(SUM(CASE WHEN paid_received = 1 THEN amount ELSE -amount END), 0) AS remaining_amount 
        FROM `$table_name`";

    $remaining_amount_result = $conn->query($remaining_amount_sql);

    if ($remaining_amount_result) {
        $remaining_amount_row = $remaining_amount_result->fetch_assoc();
        $remaining_amount = ($remaining_amount_row) ? $remaining_amount_row['remaining_amount'] : 0;
    } else {
        die("SQL Error: " . $conn->error); // Debugging error
    }
}

$totalamount += $remaining_amount; // Ensure totalamount is initialized before using

                                
                                // Determine badge color based on amount
                                $badge_class = "badge-primary";
                                if ($remaining_amount < 0) {
                                    $badge_class = "badge-danger";
                                } elseif ($remaining_amount > 0) {
                                    $badge_class = "badge-success";
                                }
                            ?>
                                <li data-customer-id="<?php echo $customer['customer_id']; ?>" class="list-group-item list-group-item-action">
                                    <i class="fas fa-user-circle mr-2"></i>
                                    <?php echo $customer['customer_name']; ?>
                                    <span class="badge <?php echo $badge_class; ?>">
                                        <?php echo $remaining_amount < 0 ? "₹" . abs($remaining_amount) . " (Due)" : "₹" . $remaining_amount; ?>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                            </ul>
                        <?php else : ?>
                            <div class="empty-state">
                                <i class="fas fa-users"></i>
                                <h4>No Customers Found</h4>
                                <p>Add your first customer to get started.</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Stock View -->
                    <div id="stock" style="display:none;">
                        <?php
                        // Fetch list of tables matching the specified format
                        $sql = "SHOW TABLES LIKE 'stock_of_%'";
                        $result = $conn->query($sql);
                        
                        if ($result && $result->num_rows > 0) {
                            echo "<ul class='list-group'>";
                            while ($row = $result->fetch_row()) {
                                // Get the table name
                                $tableName = $row[0];
                                // Format the display name
                                $displayName = ucwords(str_replace(array('stock_of_', '_'), array('', ' '), $tableName));
                                // Output each table name as a link
                                echo "<li class='list-group-item list-group-item-action'>";
                                echo "<i class='fas fa-box mr-2'></i>";
                                echo "<a href='stock/display/index.php?table_name=$tableName' class='text-decoration-none text-dark'>" . $displayName . "</a>";
                                echo "</li>";
                            }
                            echo "</ul>";
                        } else {
                            echo "<div class='empty-state'>";
                            echo "<i class='fas fa-boxes'></i>";
                            echo "<h4>No Stock Details Found</h4>";
                            echo "<p>Add your first product to get started.</p>";
                            echo "</div>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="action-buttons" id="customer-buttons">
        <a href="addcustomer/new_customer.php" class="btn action-button btn-add-customer" id="addc">
            <i class="fas fa-user-plus"></i> Add Customer
        </a>
        <a href="addbills/add_bills.php" class="btn action-button btn-add-bills" id="addb">
            <i class="fas fa-file-invoice"></i> Add Bills
        </a>
        <a href="credit/index.php?credit=<?php echo $totalamount; ?>" class="btn action-button btn-view-credit" id="credit">
            <i class="fas fa-rupee-sign"></i> Total Credit
        </a>
        <a href="profit/index.php" class="btn action-button btn-view-revenue" id="profit">
            <i class="fas fa-chart-line"></i> Revenue
        </a>
    </div>

    <div class="action-buttons" id="stock-buttons" style="display:none;">
        <a href="stock/addproduct/index.php" class="btn action-button btn-add-product" id="addproduct">
            <i class="fas fa-plus-circle"></i> Add Product
        </a>
        <a href="stock/addstock/index.php" class="btn action-button btn-add-stock" id="addstock">
            <i class="fas fa-cubes"></i> Add Stock
        </a>
        <a href="stock/displaystock/index.php" class="btn action-button btn-display-stock" id="displaystock">
            <i class="fas fa-list-alt"></i> All Stock
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Add click events to customer list items
            document.querySelectorAll('.list-group-item-action').forEach(item => {
                if (item.hasAttribute('data-customer-id')) {
                    item.addEventListener('click', event => {
                        const customerId = item.getAttribute('data-customer-id');
                        if (customerId) {
                            window.location.href = "customerprofile/customer_profile.php?id=" + customerId;
                        }
                    });
                }
            });
            
            // Set up tab switching
            const customerTab = document.getElementById('Product');
            const stockTab = document.getElementById('Amount');
            const customerView = document.getElementById('customer');
            const stockView = document.getElementById('stock');
            const customerButtons = document.getElementById('customer-buttons');
            const stockButtons = document.getElementById('stock-buttons');
            
            customerTab.addEventListener('click', function() {
                // Update tab styling
                customerTab.classList.add('active-customer');
                stockTab.classList.remove('active-stock');
                
                // Show/hide content
                customerView.style.display = 'block';
                stockView.style.display = 'none';
                
                // Show/hide action buttons
                customerButtons.style.display = 'flex';
                stockButtons.style.display = 'none';
            });
            
            stockTab.addEventListener('click', function() {
                // Update tab styling
                stockTab.classList.add('active-stock');
                customerTab.classList.remove('active-customer');
                
                // Show/hide content
                customerView.style.display = 'none';
                stockView.style.display = 'block';
                
                // Show/hide action buttons
                customerButtons.style.display = 'none';
                stockButtons.style.display = 'flex';
            });
            
            // Set initial view
            customerTab.click();
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>