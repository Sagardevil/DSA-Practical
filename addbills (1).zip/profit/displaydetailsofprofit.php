<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "../conn.php";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Indian Rupee formatting function
function formatINR($amount) {
    return '₹' . number_format((float)$amount, 2, '.', ',');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profit Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4bb543;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: #4a4a4a;
        }
        
        .dashboard-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(67, 97, 238, 0.15);
            margin-bottom: 30px;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table thead {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .table th {
            border: none;
            font-weight: 500;
            padding: 15px;
        }
        
        .table td {
            padding: 12px 15px;
            vertical-align: middle;
            border-top: 1px solid #f1f3f9;
        }
        
        .table tbody tr:hover {
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .badge {
            font-weight: 500;
            padding: 5px 10px;
            border-radius: 20px;
        }
        
        .profit-badge {
            background-color: rgba(75, 181, 67, 0.2);
            color: var(--success-color);
        }
        
        .summary-card {
            border-left: 4px solid var(--primary-color);
        }
        
        @media print {
            .no-print {
                display: none;
            }
            
            body {
                background-color: white;
                padding: 0;
            }
            
            .dashboard-header, .card {
                box-shadow: none;
            }
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade {
            animation: fadeIn 0.6s ease forwards;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <?php
    if (isset($_GET['year']) && isset($_GET['month'])) {
        $year = $_GET['year'];
        $month = str_pad($_GET['month'], 2, "0", STR_PAD_LEFT);
        $monthName = date("F", mktime(0, 0, 0, $month, 10));
        $tableName = $year . $month . "_Profit_Details";

        $sql = "SELECT id, product_name, Quantity, Price_Diff, Profit_Amount FROM `$tableName`";
        $result = $conn->query($sql);
        
        // Get summary data
        $summarySql = "SELECT 
                        COUNT(*) as total_products,
                        SUM(Quantity) as total_quantity,
                        SUM(Profit_Amount) as total_profit
                      FROM `$tableName`";
        $summaryResult = $conn->query($summarySql);
        $summary = $summaryResult->fetch_assoc();

        if ($result && $result->num_rows > 0) {
            echo "<div class='dashboard-header p-4 mb-4 animate-fade'>
                    <div class='d-flex justify-content-between align-items-center'>
                        <div>
                            <h2><i class='fas fa-chart-line me-2'></i> Profit Report</h2>
                            <p class='mb-0'>$monthName $year • Detailed profit analysis</p>
                        </div>
                        <div class='no-print'>
                            <button class='btn btn-light me-2' onclick='exportPDF()'>
                                <i class='fas fa-file-pdf me-1'></i> Export PDF
                            </button>
                            <button class='btn btn-outline-light' onclick='printTable()'>
                                <i class='fas fa-print me-1'></i> Print
                            </button>
                        </div>
                    </div>
                  </div>";
            
            // Summary cards
            echo "<div class='row mb-4 animate-fade' style='animation-delay: 0.2s'>
                    <div class='col-md-4'>
                        <div class='card summary-card h-100'>
                            <div class='card-body'>
                                <h5 class='card-title text-muted'>Total Products</h5>
                                <div class='d-flex justify-content-between align-items-center'>
                                    <h2 class='mb-0'>{$summary['total_products']}</h2>
                                    <i class='fas fa-boxes text-primary' style='font-size: 2rem; opacity: 0.7;'></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class='col-md-4'>
                        <div class='card summary-card h-100'>
                            <div class='card-body'>
                                <h5 class='card-title text-muted'>Total Quantity</h5>
                                <div class='d-flex justify-content-between align-items-center'>
                                    <h2 class='mb-0'>{$summary['total_quantity']}</h2>
                                    <i class='fas fa-layer-group text-success' style='font-size: 2rem; opacity: 0.7;'></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class='col-md-4'>
                        <div class='card summary-card h-100'>
                            <div class='card-body'>
                                <h5 class='card-title text-muted'>Total Profit</h5>
                                <div class='d-flex justify-content-between align-items-center'>
                                    <h2 class='mb-0'>" . formatINR($summary['total_profit']) . "</h2>
                                    <i class='fas fa-money-bill-wave text-danger' style='font-size: 2rem; opacity: 0.7;'></i>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>";
            
            // Data table
            echo "<div class='card animate-fade' style='animation-delay: 0.4s'>
                    <div class='card-body p-0'>
                        <div class='table-responsive'>
                            <table class='table table-hover' id='profitTable'>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                        <th>Price Diff</th>
                                        <th>Profit Amount</th>
                                    </tr>
                                </thead>
                                <tbody>";
            
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td><strong>" . htmlspecialchars($row['product_name']) . "</strong></td>
                        <td>{$row['Quantity']}</td>
                        <td>" . formatINR($row['Price_Diff']) . "</td>
                        <td><span class='badge profit-badge'>" . formatINR($row['Profit_Amount']) . "</span></td>
                      </tr>";
            }
            
            echo "</tbody>
                            </table>
                        </div>
                    </div>
                  </div>";
        } else {
            echo "<div class='alert alert-warning'>No data found in table: $tableName</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Please provide 'year' and 'month' in the URL like: ?year=2024&month=04</div>";
    }

    $conn->close();
    ?>
</div>

<script>
    async function exportPDF() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({
            orientation: 'landscape',
            unit: 'mm'
        });
        
        // Add title
        doc.setFontSize(18);
        doc.setTextColor(67, 97, 238);
        doc.text("Profit Details Report", 105, 15, { align: 'center' });
        
        // Add date
        doc.setFontSize(12);
        doc.setTextColor(100, 100, 100);
        <?php if (isset($monthName) && isset($year)): ?>
        doc.text("<?php echo $monthName . ' ' . $year; ?>", 105, 22, { align: 'center' });
        <?php endif; ?>
        
        // Add summary
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        <?php if (isset($summary)): ?>
        doc.text(`Total Products: ${<?php echo $summary['total_products']; ?>}`, 20, 30);
        doc.text(`Total Quantity: ${<?php echo $summary['total_quantity']; ?>}`, 60, 30);
        doc.text(`Total Profit: ₹${<?php echo number_format($summary['total_profit'], 2, '.', ','); ?>}`, 100, 30);
        <?php endif; ?>
        
        const table = document.getElementById("profitTable");
        let rows = [];
        
        // Add headers
        let headers = [];
        for (let j = 0; j < table.rows[0].cells.length; j++) {
            headers.push(table.rows[0].cells[j].innerText);
        }
        
        // Add rows
        for (let i = 1; i < table.rows.length; i++) {
            let row = [];
            for (let j = 0; j < table.rows[i].cells.length; j++) {
                row.push(table.rows[i].cells[j].innerText.replace('₹', ''));
            }
            rows.push(row);
        }
        
        // Add table
        doc.autoTable({
            head: [headers],
            body: rows,
            startY: 40,
            styles: {
                cellPadding: 5,
                fontSize: 9,
                valign: 'middle'
            },
            headStyles: {
                fillColor: [67, 97, 238],
                textColor: [255, 255, 255],
                fontStyle: 'bold'
            },
            alternateRowStyles: {
                fillColor: [240, 240, 245]
            },
            columnStyles: {
                3: { halign: 'right' }, // Right-align Price Diff
                4: { halign: 'right' } // Right-align Profit Amount
            },
            margin: { left: 10 }
        });
        
        // Add footer
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setTextColor(150);
            doc.text(`Page ${i} of ${pageCount}`, 200, 200, { align: 'right' });
            doc.text(`Generated on ${new Date().toLocaleDateString()}`, 10, 200);
        }
        
        doc.save("profit_report_<?php echo isset($monthName) ? strtolower($monthName) . '_' . $year : 'report'; ?>.pdf");
    }

    function printTable() {
        window.print();
    }
</script>

<!-- Include jsPDF AutoTable plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>