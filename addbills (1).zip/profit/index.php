<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profit and Month</title>
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #28a745;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: #4a4a4a;
        }
        
        .dashboard-container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 30px;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        
        .dashboard-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .dashboard-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .profit-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .profit-table thead {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .profit-table th {
            padding: 15px 20px;
            text-align: left;
            font-weight: 500;
            border: none;
        }
        
        .profit-table td {
            padding: 15px 20px;
            border-bottom: 1px solid #f1f3f9;
            vertical-align: middle;
        }
        
        .profit-table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .profit-table tbody tr:hover {
            background-color: rgba(67, 97, 238, 0.03);
        }
        
        .profit-amount {
            font-weight: 500;
            color: var(--success-color);
        }
        
        .month-display {
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .details-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .details-btn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(67, 97, 238, 0.2);
            color: white;
        }
        
        .details-btn i {
            margin-right: 6px;
        }
        
        .no-results {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 20px;
                margin: 15px;
            }
            
            .profit-table thead {
                display: none;
            }
            
            .profit-table tr {
                display: block;
                margin-bottom: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
                padding: 15px;
            }
            
            .profit-table td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 15px;
                border-bottom: 1px solid #f1f3f9;
            }
            
            .profit-table td::before {
                content: attr(data-label);
                font-weight: 500;
                color: var(--primary-color);
                margin-right: 15px;
            }
            
            .profit-table td:last-child {
                border-bottom: none;
                justify-content: flex-end;
            }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="dashboard-header">
        <h1 class="dashboard-title"><i class="fas fa-chart-line me-2"></i> Monthly Profit Report</h1>
        <p class="text-muted">View and analyze your monthly profit data</p>
    </div>

    <div class="table-responsive">
        <table class="profit-table">
            <thead>
                <tr>
                    <th>Profit</th>
                    <th>Month</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Include database connection
                include "../conn.php";

                // Query to fetch profit and month from the profit table
                $sql = "SELECT value, id FROM profit";

                // Execute the query
                $result = $conn->query($sql);

                // Check if there are rows returned
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        // Extract year and month from id
                        $year = substr($row["id"], 0, 4);
                        $month = substr($row["id"], 4, 2);

                        // Create a date string in the format "YYYY-MM-01" to use with strtotime
                        $dateString = $year . '-' . $month . '-01';

                        // Format the date to "F Y"
                        $formattedDate = date("F Y", strtotime($dateString));

                        echo '<tr>';
                        echo '<td class="profit-amount" data-label="Profit">₹' . number_format($row["value"], 2) . '</td>';
                        echo '<td class="month-display" data-label="Month">' . $formattedDate . '</td>';
                        echo '<td data-label="Details">
                                <form action="displaydetailsofprofit.php" method="GET">
                                    <input type="hidden" name="year" value="' . $year . '">
                                    <input type="hidden" name="month" value="' . $month . '">
                                    <button type="submit" class="details-btn">
                                        <i class="fas fa-eye"></i> View Details
                                    </button>
                                </form>
                              </td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="3" class="no-results">No profit records found</td></tr>';
                }

                // Close the database connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>