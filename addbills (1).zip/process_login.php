<?php
session_start();
include "conn.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user input from the form
$username = $_POST['username'];
$password = $_POST['password'];

// SQL query to check if the username and password match a record in the database
$sql = "SELECT * FROM logincre WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['logged_in'] = true;
    // Successful login, redirect to home.php
    header("Location: index.php");
    exit();
} else {
    // Invalid login, redirect back to the login form
    header("Location: login.php");
    exit();
}
?>
