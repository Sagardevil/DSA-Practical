<?php
include "../conn.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all customer names from list_of_customers table
$sql = "SELECT customer_name FROM list_of_customers";
$result = $conn->query($sql);

$customers_data = [];
$total_paid_sum = 0;
$total_received_sum = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $customer_name = str_replace(' ', '_', $row['customer_name']); 
        $table_name = $customer_name . "_amount"; 
        
        // Check if table exists
        $checkTable = "SHOW TABLES LIKE '$table_name'";
        $tableExists = $conn->query($checkTable);
        
        if ($tableExists->num_rows > 0) {
            $amount_query = "SELECT SUM(CASE WHEN paid_received = 1 THEN amount ELSE 0 END) AS total_paid,
                                     SUM(CASE WHEN paid_received = 0 THEN amount ELSE 0 END) AS total_received 
                              FROM `$table_name`";
            
            $amount_result = $conn->query($amount_query);
            
            if ($amount_result->num_rows > 0) {
                $amount_data = $amount_result->fetch_assoc();
                $total_paid = $amount_data['total_paid'] ?? 0;
                $total_received = $amount_data['total_received'] ?? 0;
                $balance = $total_paid - $total_received;
                
                $total_paid_sum += $total_paid;
                $total_received_sum += $total_received;
                
                $customers_data[] = [
                    'customername' => $customer_name,
                    'total_paid' => $total_paid,
                    'total_received' => $total_received,
                    'balance' => $balance
                ];
            }
        }
    }
}

$total_balance = $total_paid_sum - $total_received_sum;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elegant Finance Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #ffdd94, #ffb347);
            font-family: 'Poppins', sans-serif;
            color: #333;
            text-align: center;
        }
        .container {
            margin-top: 50px;
        }
        .glass-box {
            background: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        .table {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            overflow: hidden;
        }
        .table th {
            background: linear-gradient(90deg, #ff8008, #ffc837);
            color: white;
            font-size: 18px;
            padding: 15px;
        }
        .table tbody tr:hover {
            background: rgba(255, 183, 77, 0.3);
            transform: scale(1.02);
            transition: 0.3s ease-in-out;
        }
        .table tfoot td {
            font-weight: bold;
            background: rgba(255, 255, 255, 0.8);
        }
        .balance-positive {
            color: #28a745;
            font-weight: bold;
        }
        .balance-negative {
            color: #dc3545;
            font-weight: bold;
        }
        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mb-4">💰 Finance Dashboard</h1>
    <div class="glass-box fade-in">
        <div class="table-responsive">
            <table id="balanceTable" class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th>Customer Name</th>
                        <th>Total Paid (₹)</th>
                        <th>Total Received (₹)</th>
                        <th>Balance (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($customers_data as $customer): ?>
                        <tr>
                            <td align="left"><?= htmlspecialchars(str_replace('_', ' ', $customer['customername'])) ?></td>
                            <td><?= number_format($customer['total_paid'], 2) ?></td>
                            <td><?= number_format($customer['total_received'], 2) ?></td>
                            <td class="<?= $customer['balance'] >= 0 ? 'balance-positive' : 'balance-negative' ?>">
                                <?= number_format($customer['balance'], 2) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td><strong>Total</strong></td>
                        <td><strong><?= number_format($total_paid_sum, 2) ?></strong></td>
                        <td><strong><?= number_format($total_received_sum, 2) ?></strong></td>
                        <td class="<?= $total_balance >= 0 ? 'balance-positive' : 'balance-negative' ?>">
                            <strong><?= number_format($total_balance, 2) ?></strong>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- 🔘 Export Buttons -->
    <div class="mt-4 fade-in">
        <button class="btn btn-success me-2" onclick="exportToExcel()">Export to Excel</button>
        <button class="btn btn-danger me-2" onclick="exportToPDF()">Export to PDF</button>
        <button class="btn btn-primary" onclick="window.print()">Print</button>
    </div>

    <p class="footer">Powered by Your Finance System</p>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>

<script>
function exportToExcel() {
    const wb = XLSX.utils.table_to_book(document.getElementById('balanceTable'), {sheet: "CustomerBalance"});
    XLSX.writeFile(wb, 'customer_balance.xlsx');
}

async function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.text("Customer Balance Report", 14, 16);

    const rows = [];
    document.querySelectorAll("#balanceTable tbody tr").forEach(row => {
        const cells = Array.from(row.querySelectorAll("td")).map(td => td.textContent.trim());
        rows.push(cells);
    });

    const footer = document.querySelector("#balanceTable tfoot tr");
    const footerCells = Array.from(footer.querySelectorAll("td")).map(td => td.textContent.trim());
    rows.push(footerCells);

    doc.autoTable({
        head: [["Customer Name", "Total Paid (₹)", "Total Received (₹)", "Balance (₹)"]],
        body: rows,
        startY: 20
    });

    doc.save("customer_balance.pdf");
}
</script>

<!-- ✨ Fade-In Animation -->
<style>
.fade-in {
    opacity: 0;
    animation: fadeIn ease-in-out 1s forwards;
    animation-delay: 0.3s;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>

</body>
</html>

