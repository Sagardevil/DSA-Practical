<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Tirupati Sales & Rudra Trading Co.</title>
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8eb 100%);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .login-container {
            background-color: white;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
            width: 100%;
            max-width: 400px;
            transition: transform 0.3s ease;
        }
        
        .login-container:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 35px rgba(0, 0, 0, 0.12);
        }
        
        /* Logo Container */
        .logo-container {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .logo {
            width: 80px;
            height: 80px;
            object-fit: contain;
            border-radius: 50%;
            padding: 8px;
            background: white;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
            border: 1px solid #e0e6ed;
        }
        
        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 24px;
        }
        
        .company-name {
            text-align: center;
            color: #7f8c8d;
            margin-bottom: 30px;
            font-size: 14px;
            font-weight: 500;
            letter-spacing: 0.5px;
        }
        
        /* Input Fields */
        .input-group {
            position: relative;
            margin-bottom: 25px;
        }
        
        .input-group label {
            position: absolute;
            top: -10px;
            left: 40px;
            font-size: 12px;
            color: #3498db;
            background: white;
            padding: 0 5px;
            font-weight: 500;
        }
        
        input {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 1px solid #e0e6ed;
            border-radius: 8px;
            background-color: #f8fafc;
            font-size: 15px;
            color: #2c3e50;
            transition: all 0.3s ease;
        }
        
        input:focus {
            outline: none;
            border-color: #3498db;
            background-color: white;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 15px;
            color: #95a5a6;
            transition: all 0.3s ease;
        }
        
        input:focus ~ .input-icon {
            color: #3498db;
        }
        
        /* Button */
        button {
            width: 100%;
            padding: 14px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        button:hover {
            background-color: #2980b9;
            box-shadow: 0 5px 15px rgba(41, 128, 185, 0.3);
        }
        
        /* Forgot Password */
        .forgot-password {
            text-align: right;
            margin: -15px 0 20px;
        }
        
        .forgot-password a {
            color: #3498db;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .forgot-password a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <img class="logo" src="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png" alt="Company Logo">
        </div>
        <h2>Welcome Back</h2>
        <p class="company-name">Tirupati Sales & Rudra Trading Company</p>
        
        <form action="process_login.php" method="post">
            <div class="input-group">
                <input type="text" id="username" name="username" placeholder=" " required>
                <label for="username">Username</label>
                <i class="fas fa-user input-icon"></i>
            </div>
            
            <div class="input-group">
                <input type="password" id="password" name="password" placeholder=" " required>
                <label for="password">Password</label>
                <i class="fas fa-lock input-icon"></i>
            </div>
            
            <div class="forgot-password">
                <a href="#">Forgot Password?</a>
            </div>
            
            <button type="submit">Sign In</button>
        </form>
    </div>
</body>
</html>