<?php

$servername = "localhost";
$username = "sagar";
$password = "Sagar@123?1";
$dbname = "khata";



//$servername = "localhost";
//$username = "if0_38254029";
//$password = "Sagar123";
//$dbname = "if0_38254029_khata";
$conn = new mysqli($servername, $username, $password, $dbname);

?>