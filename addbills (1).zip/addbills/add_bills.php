<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Bills</title>
    <link rel="icon" href="../../logo1.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --danger-color: #e74c3c;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --border-radius: 8px;
            --transition: all 0.3s ease;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: var(--dark-color);
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px 0;
            border-bottom: 2px solid var(--primary-color);
        }

        .header h2 {
            font-size: 2.2rem;
            color: var(--primary-color);
            margin-bottom: 10px;
        }

        .card {
            background-color: #ffffff;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            margin-bottom: 30px;
            transition: var(--transition);
        }

        .card:hover {
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }

        .form-header {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark-color);
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 16px;
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
            overflow-x: auto;
            display: block;
            box-shadow: var(--shadow);
            border-radius: var(--border-radius);
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            position: sticky;
            top: 0;
        }

        tbody tr {
            border-bottom: 1px solid #f2f2f2;
            transition: var(--transition);
        }

        tbody tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        .table-responsive {
            overflow-x: auto;
            margin-bottom: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            margin: 5px;
            min-width: 120px;
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: #2980b9;
        }

        .btn-success {
            background-color: var(--secondary-color);
            color: white;
        }

        .btn-success:hover {
            background-color: #27ae60;
        }

        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }

        .btn-danger:hover {
            background-color: #c0392b;
        }

        .btn-sm {
            padding: 8px 15px;
            font-size: 14px;
            min-width: auto;
        }

        .buttons-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-top: 25px;
        }

        .button-group {
            display: flex;
            flex-wrap: wrap;
        }

        .total-container {
            background-color: #f8f9fa;
            border-radius: var(--border-radius);
            padding: 15px 20px;
            text-align: right;
            font-size: 20px;
            font-weight: 700;
            margin-top: 20px;
            border-left: 5px solid var(--primary-color);
            box-shadow: var(--shadow);
        }

        .total-container span {
            color: var(--primary-color);
            margin-left: 10px;
        }

        input[type="number"] {
            -moz-appearance: textfield;
        }

        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .action-cell {
            width: 100px;
        }

        @media print {
            .btn, .delete-row-btn, .non-printable {
                display: none !important;
            }
            
            body {
                background-color: white;
                padding: 0;
                margin: 20px;
            }
            
            .card {
                box-shadow: none;
                border: none;
            }
            
            table {
                box-shadow: none;
            }
            
            th {
                background-color: #f8f9fa !important;
                color: black !important;
                border-bottom: 2px solid #ddd;
            }
            
            .total-container {
                border-left: 2px solid #333;
                box-shadow: none;
            }

            .action-cell, .table-responsive th:last-child, .table-responsive td:last-child {
                display: none;
            }
        }

        @media screen and (max-width: 768px) {
            .form-header {
                grid-template-columns: 1fr;
            }
            
            th, td {
                padding: 10px;
            }
            
            .btn {
                padding: 10px 15px;
                font-size: 14px;
            }
            
            .buttons-container {
                flex-direction: column;
            }
            
            .button-group {
                margin-bottom: 15px;
                justify-content: center;
            }
            
            .total-container {
                text-align: center;
            }
        }

        @media screen and (max-width: 480px) {
            .card {
                padding: 15px;
            }
            
            th, td {
                padding: 8px;
                font-size: 14px;
            }
            
            .form-control {
                padding: 10px;
            }
            
            .header h2 {
                font-size: 1.8rem;
            }
        }

        /* Custom styling for autocomplete */
        .ui-autocomplete {
            max-height: 200px;
            overflow-y: auto;
            overflow-x: hidden;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            border: 1px solid #ddd;
            z-index: 1000 !important;
        }
        
        .ui-menu-item {
            padding: 8px 12px;
            font-size: 14px;
            border-bottom: 1px solid #f2f2f2;
        }
        
        .ui-menu-item:last-child {
            border-bottom: none;
        }
        
        .ui-state-focus, 
        .ui-menu-item:hover {
            background-color: #f8f9fa;
            border: none;
            color: var(--primary-color);
        }
    </style>
    <link rel="icon" type="image/png" href="https://i.ibb.co/FwrTQb3/Pics-Art-01-07-08-27-04.png">
</head>

<body>
    <?php
    $customername="a";
    include "../conn.php";

    $detailstablename =  date("Ym")."_Profit_Details"; // Format: YYYYMM

    // SQL command to create the table if it doesn't exist
    $detailstablenamesql = "CREATE TABLE IF NOT EXISTS `$detailstablename` (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        Product_Name VARCHAR(100) NOT NULL,
        Quantity VARCHAR(100) NOT NULL,
        Price_Diff VARCHAR(100) NOT NULL,
        Profit_Amount VARCHAR(100) NOT NULL
    )";
    
    // Execute the SQL query
    $conn->query($detailstablenamesql);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if(isset($_GET['id'])){
        $selectqq="select * from list_of_customers where customer_id= ?";
        $selectqqresult=$conn->prepare($selectqq);
        $selectqqresult->bind_param("d",$id);

        if($selectqqresult->execute()){
            if($selectqqresult->num_rows>0){
                while($row=$selectqqresult->fetch_assoc()){
                    $customername=$row["customer_name"];
                }
            }
        }
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assuming the form data is submitted as arrays
        $productNames = $_POST["productName"];
        $quantities = $_POST["quantity"];
        $prices = $_POST["price"];
    
        $rowCount = count($productNames);
        $totalProfit = 0;
        $shopName = $_POST["shopName"];
        $selectedDate = $_POST["selectedDate"];
    
        // Sanitize the shop name: replace spaces with underscores
        $shopName = str_replace(' ', '_', $shopName);
    
        // Convert selected date to the required format for table name
        $formattedDate = date('dmY', strtotime($selectedDate));
    
        // Construct the final table name
        $final = $shopName . '_' . $formattedDate;
    
        // Create the table if it doesn't exist
        $createTableQuery = "CREATE TABLE IF NOT EXISTS $final (
            productName VARCHAR(255),
            quantity INT,
            price INT
        )";
        if ($conn->query($createTableQuery) === FALSE) {
            echo "Error creating table: " . $conn->error;
        }
    
        for ($i = 0; $i < $rowCount; $i++) {
            // Retrieve product name, quantity, and price from the form data
            $productName = $conn->real_escape_string($productNames[$i]);
            $quantity = intval($quantities[$i]);
            $productPrice = intval($prices[$i]);
    
            // Update 'main' table to remove stock
            $updateQuery = "UPDATE list_of_products SET quantity = quantity - ? WHERE product_name = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("is", $quantity, $productName);
    
            if ($updateStmt->execute()) {
                // Retrieve the original price from the 'main' table
                $selectQuery = "SELECT product_rate FROM list_of_products WHERE product_name=?";
                $selectStmt = $conn->prepare($selectQuery);
                $selectStmt->bind_param("s", $productName);
                $selectStmt->execute();
                $selectStmt->bind_result($originalPrice);
                $selectStmt->fetch();
                $selectStmt->close();
    
                // Calculate the profit for this product
                $profit = ($productPrice - $originalPrice) * $quantity;
                $priceDiff=$productPrice-$originalPrice;
                $isnertintodetailsofprofit="INSERT INTO `$detailstablename` (Product_Name, Quantity, Price_Diff, Profit_Amount) 
                VALUES ('$productName', '$quantity', '$priceDiff', '$profit')";
                $conn->query($isnertintodetailsofprofit);

                $totalProfit += $profit;
            } else {
                echo "<p>Error removing stock: " . $updateStmt->error . "</p>";
            }
    
            // Insert data into the final table
            $insertDataQuery = "INSERT INTO $final (productName, quantity, price) VALUES (?, ?, ?)";
            $insertStmt = $conn->prepare($insertDataQuery);
            $insertStmt->bind_param("sii", $productName, $quantity, $productPrice);
            if (!$insertStmt->execute()) {
                echo "<p>Error inserting data: " . $insertStmt->error . "</p>";
            }
    
            // Close the prepared statement
            $updateStmt->close();
            $insertStmt->close();
        }
    
        // Update the 'profit' table with the total profit
        $currentYear = date('Y');
        $currentMonth = date('n');
    
        // Combine year and month to form the id
        $currentId = intval($currentYear . sprintf("%02d", $currentMonth));
    
        // Check if the id exists in the 'profit' table
        $checkIdQuery = "SELECT COUNT(*) FROM profit WHERE id = ?";
        $checkIdStmt = $conn->prepare($checkIdQuery);
        $checkIdStmt->bind_param("i", $currentId);
        $checkIdStmt->execute();
        $checkIdStmt->bind_result($idCount);
        $checkIdStmt->fetch();
        $checkIdStmt->close();
    
        if ($idCount == 0) {
            // If the id doesn't exist, insert it into the 'profit' table
            $insertIdQuery = "INSERT INTO profit (id, value) VALUES (?, 0)";
            $insertIdStmt = $conn->prepare($insertIdQuery);
            $insertIdStmt->bind_param("i", $currentId);
            $insertIdStmt->execute();
            $insertIdStmt->close();
        }
    
        // Update the 'profit' table with the total profit for the current year and month
        $updateProfitQuery = "UPDATE profit SET value = value + ? WHERE id = ?";
        $updateProfitStmt = $conn->prepare($updateProfitQuery);
        $updateProfitStmt->bind_param("ii", $totalProfit, $currentId);
    
        if ($updateProfitStmt->execute()) {
            echo "<script>alert('Bill Added Successfully !'); window.location='../index.php';</script>";
        } else {
            echo "<p>Error updating profit: " . $updateProfitStmt->error . "</p>";
        }
    
        // Close the prepared statement
        $updateProfitStmt->close();
    }
    
    $conn->close();
    ?>
    
    <div class="container">
        <div class="header non-printable">
            <h2><i class="fas fa-file-invoice-dollar"></i> Add Bills</h2>
        </div>

        <form action="" method="post">
            <div class="card">
                <div class="form-header">
                    <div class="form-group">
                        <label for="shopName"><i class="fas fa-store"></i> Shop Name:</label>
                        <?php
                        if($customername=="a"){
                            echo '<input type="text" id="shopName" name="shopName" required class="form-control" placeholder="Enter shop name">';
                        }
                        else{
                            echo '<input type="text" id="shopName" name="shopName" required value="'.$customername.'" class="form-control" placeholder="Enter shop name">';
                        }
                        ?>
                        <!-- Hidden input to pass the shop name to the server -->
                        <input type="hidden" id="hiddenShopName" name="hiddenShopName">
                    </div>
                    
                    <div class="form-group">
                        <label for="selectedDate"><i class="fas fa-calendar-alt"></i> Date:</label>
                        <input type="date" id="selectedDate" name="selectedDate" required class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="address"><i class="fas fa-map-marker-alt"></i> Address:</label>
                        <input type="text" id="address" name="address" class="form-control" placeholder="Enter address">
                    </div>
                </div>

                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="fas fa-box"></i> Product Name</th>
                                <th><i class="fas fa-hashtag"></i> Quantity</th>
                                <th><i class="fas fa-tag"></i> Price</th>
                                <th><i class="fas fa-calculator"></i> Amount</th>
                                <th class="action-cell"><i class="fas fa-cogs"></i> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="text" name="productName[]" class="product-name-input form-control" placeholder="Product name" /></td>
                                <td><input type="number" name="quantity[]" class="quantity-input form-control" oninput="calculateAmount(this)" placeholder="0" /></td>
                                <td><input type="number" name="price[]" class="price-input form-control" oninput="calculateAmount(this)" placeholder="0.00" /></td>
                                <td><input type="number" name="amount[]" class="amount-input form-control" readonly placeholder="0.00" /></td>
                                <td class="action-cell">
                                    <button type="button" class="btn btn-danger btn-sm delete-row-btn" onclick="deleteRow(this)">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="total-container" id="totalBill">Total Bill Amount: <span>0.00</span></div>

                <div class="buttons-container">
                    <div class="button-group non-printable">
                        <button type="button" class="btn btn-primary" onclick="addRow()">
                            <i class="fas fa-plus"></i> Add Row
                        </button>
                        <button type="button" class="btn btn-danger delete-all-btn" onclick="deleteAllRows()">
                            <i class="fas fa-trash"></i> Delete All
                        </button>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn btn-success add-bills-btn">
                            <i class="fas fa-save"></i> Save Bill
                        </button>
                        <button type="button" class="btn btn-primary print-btn" onclick="printPage()">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <script>
        function printPage() {
            window.print();
        }

        // Function to fetch product names from server
        async function fetchProductNames() {
            try {
                const response = await fetch('fetch_product_names.php');
                const productNames = await response.json();
                return productNames;
            } catch (error) {
                console.error("Error fetching product names:", error);
                return [];
            }
        }

        // Function to fetch customer names from server
        async function fetchCustomerNames() {
            try {
                const response = await fetch('fetch_customer_names.php');
                const customerNames = await response.json();
                return customerNames;
            } catch (error) {
                console.error("Error fetching customer names:", error);
                return [];
            }
        }

        // Initialize autocomplete for an input field
        function initAutocomplete(input, source) {
            input.autocomplete({
                source: source,
                minLength: 1,
                focus: function(event, ui) {
                    event.preventDefault();
                    input.val(ui.item.value);
                },
                select: function(event, ui) {
                    setTimeout(() => {
                        if (input.hasClass('product-name-input')) {
                            const row = input.closest('tr');
                            const quantityInput = row.querySelector('.quantity-input');
                            if (quantityInput && !quantityInput.value) {
                                quantityInput.focus();
                            }
                        }
                    }, 100);
                }
            });
        }

        // When DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Set default date to today
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('selectedDate').value = today;
            
            // Initialize autocomplete for both product names and customer names
            Promise.all([fetchProductNames(), fetchCustomerNames()]).then(([productNames, customerNames]) => {
                // Initialize product name autocomplete for existing rows
                document.querySelectorAll('.product-name-input').forEach(input => {
                    initAutocomplete($(input), productNames);
                });
                
                // Initialize customer name autocomplete
                const shopNameInput = $('#shopName');
                initAutocomplete(shopNameInput, customerNames);
                
                // Update hidden input when a customer is selected
                shopNameInput.on('autocompleteselect', function(event, ui) {
                    $('#hiddenShopName').val(ui.item.value);
                });
            });
        });

        function addRow() {
            var tableBody = document.querySelector("table tbody");
            var newRow = tableBody.insertRow(tableBody.rows.length);

            var cell1 = newRow.insertCell(0);
            var cell2 = newRow.insertCell(1);
            var cell3 = newRow.insertCell(2);
            var cell4 = newRow.insertCell(3);
            var cell5 = newRow.insertCell(4);

            cell1.innerHTML = '<input type="text" name="productName[]" class="product-name-input form-control" placeholder="Product name" />';
            cell2.innerHTML = '<input type="number" name="quantity[]" class="quantity-input form-control" oninput="calculateAmount(this)" placeholder="0" />';
            cell3.innerHTML = '<input type="number" name="price[]" class="price-input form-control" oninput="calculateAmount(this)" placeholder="0.00" />';
            cell4.innerHTML = '<input type="number" name="amount[]" class="amount-input form-control" readonly placeholder="0.00" />';
            cell5.innerHTML = '<button type="button" class="btn btn-danger btn-sm delete-row-btn" onclick="deleteRow(this)"><i class="fas fa-trash-alt"></i></button>';
            cell5.className = "action-cell";

            // Enable autocomplete for the new row's product name
            fetchProductNames().then(productNames => {
                initAutocomplete($(cell1).find(".product-name-input"), productNames);
            });
            
            // Focus on the new product field
            setTimeout(() => {
                cell1.querySelector('input').focus();
            }, 10);
        }

        function deleteRow(button) {
            if (document.querySelectorAll('table tbody tr').length > 1) {
                var row = button.closest('tr');
                row.parentNode.removeChild(row);
                calculateTotalBill();
            } else {
                alert("At least one product row is required!");
            }
        }

        function deleteAllRows() {
            var tableBody = document.querySelector("table tbody");
            while (tableBody.rows.length > 0) {
                tableBody.deleteRow(0);
            }
            addRow(); // Add a fresh row
            calculateTotalBill();
        }

        function calculateAmount(element) {
            var row = element.closest('tr');
            var quantity = parseFloat(row.querySelector('.quantity-input').value) || 0;
            var price = parseFloat(row.querySelector('.price-input').value) || 0;
            var amount = quantity * price;
            row.querySelector('.amount-input').value = amount.toFixed(2);
            calculateTotalBill();
        }

        function calculateTotalBill() {
            var total = 0;
            document.querySelectorAll('.amount-input').forEach(function(input) {
                total += parseFloat(input.value) || 0;
            });
            document.getElementById('totalBill').innerHTML = 'Total Bill Amount: <span>' + total.toFixed(2) + '</span>';
        }

        // Handle keyboard navigation for tab key to improve UX
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.classList.contains('form-control')) {
                e.preventDefault();
                const inputs = Array.from(document.querySelectorAll('.form-control:not([readonly])'));
                const currentIndex = inputs.indexOf(e.target);
                const nextInput = inputs[currentIndex + 1];
                
                if (nextInput) {
                    nextInput.focus();
                } else {
                    // If it's the last input field, add a new row and focus on the first field
                    addRow();
                }
            }
        });
    </script>
</body>
</html>