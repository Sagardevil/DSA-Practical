<?php
include "../conn.php";

$query = "SELECT customer_name FROM list_of_customers";
$result = $conn->query($query);

$customerNames = array();
while ($row = $result->fetch_assoc()) {
    $customerNames[] = $row['customer_name'];
}

header('Content-Type: application/json');
echo json_encode($customerNames);

$conn->close();
?>