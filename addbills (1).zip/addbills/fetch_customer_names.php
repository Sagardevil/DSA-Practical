<?php
// Replace with your actual database credentials
include "../conn.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch shop names from the customer table
$sql = "SELECT DISTINCT customer_name FROM list_of_customers";
$result = $conn->query($sql);

$shopNames = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $shopNames[] = $row["customer_name"];
    }
}

// Return shop names as JSON
header('Content-Type: application/json');
echo json_encode($shopNames);

$conn->close();
?>
