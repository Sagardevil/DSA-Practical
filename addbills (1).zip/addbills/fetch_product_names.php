<?php
// Assuming you have a MySQL database connection established
include "../conn.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch product names from the 'list' table
$productNames = array();
$selectQuery = "SELECT product_name FROM list_of_products";
$result = $conn->query($selectQuery);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productNames[] = $row['product_name'];
    }
}

// Close the database connection
$conn->close();

// Return product names as JSON
echo json_encode($productNames);
?>
