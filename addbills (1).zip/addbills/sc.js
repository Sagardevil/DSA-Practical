async function fetchProductNames() {
    const response = await fetch('fetch_product_names.php'); // Replace with your server-side script to fetch product names
    const productNames = await response.json();
    return productNames;
}

function initAutocomplete(input) {
    input.autocomplete({
        source: productNames,
        focus: function (event, ui) {
            event.preventDefault();
            input.val(ui.item.value);
        }
    });
}

var productNames;
fetchProductNames().then(names => {
    productNames = names;
    initAutocomplete($('.product-name-input'));
});