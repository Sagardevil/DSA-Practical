<?php
include('../auth.php');
check_login();

// Database connection
include '../conn.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch customer names for auto-suggestions
$customer_names = [];
$sql_customers = "SELECT customer_name FROM list_of_customers";
$result_customers = $conn->query($sql_customers);

if ($result_customers->num_rows > 0) {
    while ($row = $result_customers->fetch_assoc()) {
        $customer_names[] = $row['customer_name'];
    }
}

// Fetch product names for auto-suggestions
$product_names = [];
$sql_products = "SELECT product_name FROM list_of_products";
$result_products = $conn->query($sql_products);

if ($result_products->num_rows > 0) {
    while ($row = $result_products->fetch_assoc()) {
        $product_names[] = $row['product_name'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = $_POST['customer_name'];
    $date = $_POST['bill_date'];
    $product_names_post = $_POST['product_name'];
    $quantities = $_POST['product_quantity'];
    $rates = $_POST['product_rate'];
    $amounts = $_POST['product_amount'];

    $formatted_date = date('dmY', strtotime($date));
    $table_name = $customer_name . '_' . $formatted_date;

    // Create table for customer bill if not exists
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_name VARCHAR(255) NOT NULL,
        quantity INT NOT NULL,
        rate DECIMAL(10, 2) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL
    )";

    if ($conn->query($create_table_sql) === TRUE) {
        $total_amount = 0;

        foreach ($product_names_post as $index => $product_name) {
            $quantity = $quantities[$index];
            $rate = $rates[$index];
            $amount = $amounts[$index];
            $total_amount += $amount;

            $insert_sql = "INSERT INTO `$table_name` (product_name, quantity, rate, amount) VALUES ('$product_name', '$quantity', '$rate', '$amount')";

            if (!$conn->query($insert_sql)) {
                echo "Error: " . $conn->error;
            }
        }

        // Redirect to display page with total amount
        header("Location: display.php?table=$table_name&total=$total_amount");
        exit();
    } else {
        echo "Error creating table: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Bill</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
    <style>
        .container {
            margin-top: 50px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .table {
            margin-top: 20px;
        }
        .table th, .table td {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4">Add Bill</h2>
        <form id="bill-form" method="POST">
            <div class="form-group">
                <label for="customer_name">Customer Name:</label>
                <input type="text" class="form-control" id="customer_name" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="bill_date">Date:</label>
                <input type="date" class="form-control" id="bill_date" name="bill_date" required>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered" id="products-table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Rate</th>
                            <th>Amount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <input type="text" class="form-control product_name_input" name="product_name[]" required>
                            </td>
                            <td><input type="number" class="form-control" name="product_quantity[]" min="1" required></td>
                            <td><input type="number" step="0.01" class="form-control" name="product_rate[]" required></td>
                            <td><input type="number" step="0.01" class="form-control" name="product_amount[]" readonly></td>
                            <td><button type="button" class="btn btn-success" onclick="addRow()">Add</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="button" class="btn btn-secondary" onclick="window.history.back()">Back</button>
            </div>
        </form>
        <div id="form-output" class="mt-4"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script>
        $(document).ready(function() {
            // Autocomplete for customer name
            $("#customer_name").autocomplete({
                source: <?php echo json_encode($customer_names); ?>,
                minLength: 1
            });

            // Autocomplete for product name
            $(document).on("focus", ".product_name_input", function() {
                $(this).autocomplete({
                    source: <?php echo json_encode($product_names); ?>,
                    minLength: 1
                });
            });
        });

        function addRow() {
            var row = `
                <tr>
                    <td>
                        <input type="text" class="form-control product_name_input" name="product_name[]" required>
                    </td>
                    <td><input type="number" class="form-control" name="product_quantity[]" min="1" required></td>
                    <td><input type="number" step="0.01" class="form-control" name="product_rate[]" required></td>
                    <td><input type="number" step="0.01" class="form-control" name="product_amount[]" readonly></td>
                    <td><button type="button" class="btn btn-danger" onclick="deleteRow(this)">Delete</button></td>
                </tr>
            `;
            $("#products-table tbody").append(row);
        }

        function deleteRow(button) {
            var row = button.parentNode.parentNode;
            row.parentNode.removeChild(row);
        }

        document.getElementById('bill-form').addEventListener('submit', function(event) {
            event.preventDefault();
            var form = event.target;
            var formData = new FormData(form);
            var output = "<h4>Bill Details:</h4>";
            output += "<p>Customer Name: " + formData.get('customer_name') + "</p>";
            output += "<p>Date: " + formData.get('bill_date') + "</p>";
            output += "<table class='table table-bordered'><thead><tr><th>Product Name</th><th>Quantity</th><th>Rate</th><th>Amount</th></tr></thead><tbody>";

            var totalAmount = 0;
            for (var i = 0; i < formData.getAll('product_name[]').length; i++) {
                var product_name = formData.getAll('product_name[]')[i];
                var product_quantity = formData.getAll('product_quantity[]')[i];
                var product_rate = formData.getAll('product_rate[]')[i];
                var product_amount = (product_quantity * product_rate).toFixed(2);
                totalAmount += parseFloat(product_amount);
                output += "<tr><td>" + product_name + "</td><td>" + product_quantity + "</td><td>" + product_rate + "</td><td>" + product_amount + "</td></tr>";
            }

            output += "</tbody></table>";
            output += "<h4>Total Bill Amount: " + totalAmount.toFixed(2) + "</h4>";
            document.getElementById('form-output').innerHTML = output;
        });

        document.getElementById('products-table').addEventListener('input', function(event) {
            if (event.target.name === 'product_quantity[]' || event.target.name === 'product_rate[]') {
                var row = event.target.closest('tr');
                var quantity = row.querySelector('input[name="product_quantity[]"]').value;
                var rate = row.querySelector('input[name="product_rate[]"]').value;
                var amount = (quantity * rate).toFixed(2);
                row.querySelector('input[name="product_amount[]"]').value = amount;
            }
        });
    </script>
</body>
</html>
