<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include "../conn.php";

// Check if required parameters are provided
if (!isset($_GET['type']) || !isset($_GET['customer_id'])) {
    header("Location: ../index.php");
    exit();
}

$report_type = $_GET['type'];
$customer_id = $_GET['customer_id'];

// Fetch customer details
$sql_customer = "SELECT * FROM list_of_customers WHERE customer_id = ?";
$stmt_customer = $conn->prepare($sql_customer);
$stmt_customer->bind_param("i", $customer_id);
$stmt_customer->execute();
$result_customer = $stmt_customer->get_result();

if ($result_customer->num_rows === 0) {
    die("Customer not found");
}

$customer = $result_customer->fetch_assoc();
$customer_name = $customer['customer_name'];
$customer_table = str_replace(' ', '_', $customer_name) . '_amount';

// Check if customer's transaction table exists
$check_table = "SHOW TABLES LIKE '$customer_table'";
$table_exists = $conn->query($check_table);

if ($table_exists->num_rows === 0) {
    die("No transaction records found for this customer");
}

// Function to generate PDF report
function generatePDF($title, $html_content) {
    require_once('../tcpdf/tcpdf.php');
    
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Tirupati Sales');
    $pdf->SetTitle($title);
    $pdf->SetSubject('Customer Report');
    
    // Set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    
    // Set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    
    // Add a page
    $pdf->AddPage();
    
    // Set font
    $pdf->SetFont('helvetica', '', 10);
    
    // Add HTML content
    $pdf->writeHTML($html_content, true, false, true, false, '');
    
    // Output PDF
    $pdf->Output($title . '.pdf', 'I');
}

// Generate report based on type
switch ($report_type) {
    case 'monthly':
        generateMonthlyStatement($customer_id, $customer_name, $customer_table);
        break;
    case 'transaction':
        generateTransactionHistory($customer_id, $customer_name, $customer_table);
        break;
    case 'payment':
        generatePaymentSummary($customer_id, $customer_name, $customer_table);
        break;
    default:
        die("Invalid report type");
}

function generateMonthlyStatement($customer_id, $customer_name, $customer_table) {
    global $conn;
    
    // Get current month and year
    $current_month = date('m');
    $current_year = date('Y');
    
    // Calculate first and last day of current month
    $first_day = date('Y-m-01');
    $last_day = date('Y-m-t');
    
    // Get all transactions for current month
    $sql = "SELECT * FROM $customer_table 
            WHERE transaction_date BETWEEN ? AND ?
            ORDER BY transaction_date DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $first_day, $last_day);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Calculate totals
    $total_purchased = 0;
    $total_received = 0;
    $transactions = [];
    
    while ($row = $result->fetch_assoc()) {
        if ($row['paid_received'] == 1) {
            $total_purchased += $row['amount'];
        } else {
            $total_received += $row['amount'];
        }
        $transactions[] = $row;
    }
    
    $balance = $total_purchased - $total_received;
    
    // Generate HTML for PDF
    $html = '
    <h1 style="text-align:center;">Monthly Statement</h1>
    <h3 style="text-align:center;">' . htmlspecialchars($customer_name) . '</h3>
    <p style="text-align:center;">' . date('F Y') . '</p>
    
    <table border="1" cellpadding="5">
        <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Amount (₹)</th>
            <th>Description</th>
        </tr>';
    
    foreach ($transactions as $transaction) {
        $type = $transaction['paid_received'] == 1 ? 'Purchase' : 'Payment';
        $html .= '
        <tr>
            <td>' . $transaction['transaction_date'] . '</td>
            <td>' . $type . '</td>
            <td>' . $transaction['amount'] . '</td>
            <td>' . htmlspecialchars($transaction['notes']) . '</td>
        </tr>';
    }
    
    $html .= '
    </table>
    
    <h3>Summary</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Total Purchased</th>
            <td>₹' . $total_purchased . '</td>
        </tr>
        <tr>
            <th>Total Received</th>
            <td>₹' . $total_received . '</td>
        </tr>
        <tr>
            <th>Current Balance</th>
            <td>₹' . abs($balance) . ' (' . ($balance > 0 ? 'Due' : ($balance < 0 ? 'Advance' : 'Settled')) . ')</td>
        </tr>
    </table>
    
    <p style="text-align:right; margin-top:20px;">
        <strong>Generated on:</strong> ' . date('Y-m-d H:i:s') . '
    </p>';
    
    generatePDF('Monthly_Statement_' . $customer_name . '_' . date('F_Y'), $html);
}

function generateTransactionHistory($customer_id, $customer_name, $customer_table) {
    global $conn;
    
    // Get all transactions
    $sql = "SELECT * FROM $customer_table ORDER BY transaction_date DESC";
    $result = $conn->query($sql);
    
    // Calculate totals
    $total_purchased = 0;
    $total_received = 0;
    $transactions = [];
    
    while ($row = $result->fetch_assoc()) {
        if ($row['paid_received'] == 1) {
            $total_purchased += $row['amount'];
        } else {
            $total_received += $row['amount'];
        }
        $transactions[] = $row;
    }
    
    $balance = $total_purchased - $total_received;
    
    // Generate HTML for PDF
    $html = '
    <h1 style="text-align:center;">Transaction History</h1>
    <h3 style="text-align:center;">' . htmlspecialchars($customer_name) . '</h3>
    
    <table border="1" cellpadding="5">
        <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Amount (₹)</th>
            <th>Description</th>
        </tr>';
    
    foreach ($transactions as $transaction) {
        $type = $transaction['paid_received'] == 1 ? 'Purchase' : 'Payment';
        $html .= '
        <tr>
            <td>' . $transaction['transaction_date'] . '</td>
            <td>' . $type . '</td>
            <td>' . $transaction['amount'] . '</td>
            <td>' . htmlspecialchars($transaction['notes']) . '</td>
        </tr>';
    }
    
    $html .= '
    </table>
    
    <h3>Summary</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Total Purchased</th>
            <td>₹' . $total_purchased . '</td>
        </tr>
        <tr>
            <th>Total Received</th>
            <td>₹' . $total_received . '</td>
        </tr>
        <tr>
            <th>Current Balance</th>
            <td>₹' . abs($balance) . ' (' . ($balance > 0 ? 'Due' : ($balance < 0 ? 'Advance' : 'Settled')) . ')</td>
        </tr>
    </table>
    
    <p style="text-align:right; margin-top:20px;">
        <strong>Generated on:</strong> ' . date('Y-m-d H:i:s') . '
    </p>';
    
    generatePDF('Transaction_History_' . $customer_name, $html);
}

function generatePaymentSummary($customer_id, $customer_name, $customer_table) {
    global $conn;
    
    // Get all payment transactions
    $sql = "SELECT * FROM $customer_table 
            WHERE paid_received = 0 
            ORDER BY transaction_date DESC";
    $result = $conn->query($sql);
    
    // Calculate total payments
    $total_received = 0;
    $payments = [];
    
    while ($row = $result->fetch_assoc()) {
        $total_received += $row['amount'];
        $payments[] = $row;
    }
    
    // Generate HTML for PDF
    $html = '
    <h1 style="text-align:center;">Payment Summary</h1>
    <h3 style="text-align:center;">' . htmlspecialchars($customer_name) . '</h3>
    
    <table border="1" cellpadding="5">
        <tr>
            <th>Date</th>
            <th>Amount (₹)</th>
            <th>Method</th>
            <th>Description</th>
        </tr>';
    
    foreach ($payments as $payment) {
        $html .= '
        <tr>
            <td>' . $payment['transaction_date'] . '</td>
            <td>' . $payment['amount'] . '</td>
            <td>' . htmlspecialchars($payment['payment_method'] ?? 'Cash') . '</td>
            <td>' . htmlspecialchars($payment['notes']) . '</td>
        </tr>';
    }
    
    $html .= '
    </table>
    
    <h3>Summary</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Total Payments Received</th>
            <td>₹' . $total_received . '</td>
        </tr>
    </table>
    
    <p style="text-align:right; margin-top:20px;">
        <strong>Generated on:</strong> ' . date('Y-m-d H:i:s') . '
    </p>';
    
    generatePDF('Payment_Summary_' . $customer_name, $html);
}
?>